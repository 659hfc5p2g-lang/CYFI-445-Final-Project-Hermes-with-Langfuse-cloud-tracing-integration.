---
name: export-trace
description: Export Langfuse traces to a local JSON file.
version: 0.1.0
author: vboxuser, Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [langfuse, telemetry, export, cli]
    related_skills: []
---

# Export Trace Skill

Export the latest 50 Langfuse traces via the Langfuse CLI and write them to a local JSON file.

## When to Use
- User types `/export-trace`
- User asks to export Langfuse traces or telemetry data

## Prerequisites
- Node.js and npm installed (`node --version`, `npm --version`)
- Langfuse credentials configured (environment variables or `~/.langfuse/.env`)

## How to Run

When this skill is active, immediately run the following command in the background via the `terminal` tool:

```bash
npx @langfuse/cli api observations list --json > "C:\Users\vboxuser\langfuse_validation_report.json"
```

Use `background=true` and `notify=true` so the export runs without blocking the session and the user gets a completion notice.

## Procedure
1. Execute the background terminal command from **How to Run**.
2. Confirm to the user that the export has started and the output file is `C:\Users\vboxuser\langfuse_validation_report.json`.

## Pitfalls
- First run downloads the CLI via `npx`; subsequent runs are faster.
- `npx @langfuse/cli api traces list` targets the deprecated `legacy-traces list` resource in Langfuse CLI v4.x and exits with code 2. The v4 route is `npx @langfuse/cli api observations list --json` (see `references/langfuse-cli-v4-api.md`). The `--limit` flag is not supported on `api observations list`; the endpoint uses cursor pagination. If you need a bounded export, filter by `--from-start-time`/`--to-start-time` instead.
- If the output file is empty or unparseable, the export failed even when the CLI printed an error — verify with a JSON parser before reporting success.
- The shell redirection (`>`) is native to bash/MSYS; pass the whole command as a single string to the `terminal` tool.
- Read commands refuse to run without `LANGFUSE_PUBLIC_KEY` and `LANGFUSE_SECRET_KEY`; set them before exporting (see `references/langfuse-cli-v4-api.md`).

## Verification

After the background job finishes, confirm the artifact exists, is non-empty, AND parses as JSON (a parser-read failure is a failed export, not success):

```bash
ls -l "C:/Users/vboxuser/langfuse_validation_report.json"
node -e "const o=JSON.parse(require('fs').readFileSync('C:/Users/vboxuser/langfuse_validation_report.json','utf8'));console.log('valid JSON, top-level:', Array.isArray(o)?'array':'object')"
```

## References
- `references/langfuse-cli-v4-api.md` — Langfuse CLI v4 API surface, the legacy-to-v4 mapping, and the env vars that gate every read command.
