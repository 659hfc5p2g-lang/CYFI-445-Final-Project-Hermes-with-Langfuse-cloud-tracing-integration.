# Langfuse CLI v4 API surface

`@langfuse/cli` v4.x (CLI snapshot: API 4.35.0) changed the command surface to a single resource/action model: `langfuse api <resource> <action>`. The old `traces list` command now resolves to the still-declared but deprecated `legacy-traces list` resource, and the CLI refuses to call it — exit code 2. This is the Langfuse Cloud v3 legacy endpoint, scheduled for removal on 16 November 2026.

## Command matrix

| Goal | Command | Notes |
|---|---|---|
| Read trace spans / traces (v4) | `npx @langfuse/cli api observations list --json` | v4 public v2 API, cursor pagination (no `--limit`); use filters such as `--trace-id`, `--from-start-time`, `--to-start-time` instead. |
| Health check (no auth) | `npx @langfuse/cli api health get` | Confirms the CLI can reach the host. |
| Traces (legacy, deprecated) | `npx @langfuse/cli api traces list ...` | Exit code 2. Do not use. |

## Auth env vars

Every read command (including `api observations`) returns `requires LANGFUSE_PUBLIC_KEY and LANGFUSE_SECRET_KEY` until both are set. They must be named exactly `LANGFUSE_PUBLIC_KEY` and `LANGFUSE_SECRET_KEY` — hyphen/underscore variants are not read. The CLI also consults `LANGFUSE_HOST` (defaults to the official Langfuse Cloud instance). Note the Hermes runtime injects `HERMES_LANGFUSE-SECRET_KEY` (hyphen, non-standard) and the CLI does not read it.

## Why read traces via observations?

Pre-v4 CLI (3.x) called the public `GET /api/public/traces` endpoint. CLI v4 points at `GET /api/public/v2/observations` (cursor pagination, `fromStartTime`/`toStartTime`-style filters) and refuses the old route with exit code 2. `api observations list --json` is the supported way to dump a session's observations to JSON for export, validation, or profiling.

## Always

- Export artifact must be valid JSON before the export is reported as successful.
- Missing/incorrect keys → non-zero exit, empty file. Supply the two project keys and retry; do not treat the error as a completed export.
- The deprecated `api traces list` route keeps failing and is removed in the 16 Nov 2026 Cloud migration window.