---
name: trace-analyzer
description: "Analyze Langfuse traces against a baseline export."
version: 1.0.0
author: vboxuser, Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [langfuse, telemetry, analysis, validation, observability]
    related_skills: [export-trace]
---

# Trace Analyzer

Orchestrate a Langfuse trace analysis loop: fetch live observations/scores, compare against a baseline session export, and emit a JSON graph, Mermaid flowchart, and differential validation scorecard.

## When to Use
- User types `/trace-analyze --id <trace_id> --baseline <filepath>`
- User asks to analyze a Langfuse trace against a baseline export

## Prerequisites
- Node.js and npm installed (`node --version`, `npm --version`)
- Langfuse credentials configured (environment variables or `~/.langfuse/.env`)
- Baseline export JSON file exists at the provided `--baseline` path

## Invocation

The skill receives two arguments from the slash command:
- `--id <trace_id>` — the live Langfuse trace ID to inspect
- `--baseline <filepath>` — path to a local Langfuse session export JSON

Example:
```
/trace-analyze --id abc-123 --baseline C:\Users\vboxuser\langfuse_validation_report.json
```

## Procedure

### Step 1: Fetch Live Telemetry

Run both commands in parallel via `terminal` with `background=false` so the agent can capture stdout:

```bash
npx @langfuse/cli api observations list --trace-id <trace_id> --json
```

```bash
npx @langfuse/cli api scores list --trace-id <trace_id> --json
```

If either command fails (non-zero exit or missing CLI), stop and report the error.

### Step 2: Load Baseline

Read the file at `--baseline` using `read_file`. Parse it as JSON.

### Step 3: Compute & Compare

1. **Golden sequence template:** Isolate the `body.data` array inside the baseline export. Each entry is an observation with `name`, `type`, `startTime`, `endTime`, and `latency`.
2. **Sequence check:** Compare the live observation execution order against the baseline template. Mark any out-of-order steps.
3. **Latency check:** Calculate live trace total latency and compare against the maximum latency in the baseline export.
4. **Cost check:** Observation-level exports do not include token/cost fields. If neither live nor baseline observations carry `totalPrice`, `inputPrice`, `outputPrice`, or equivalent token counts, report `N/A` in the scorecard instead of fabricating a comparison.

### Step 4: Emit Artifacts

Emit exactly three artifacts in the final response:

#### 1. JSON Graph (Machine-Readable Topology)

Provide a raw JSON code block with this shape:

```json
{
  "trace_id": "<trace_id>",
  "nodes": [
    { "id": "step-1", "name": "Tool Call", "type": "tool", "latency_ms": 120, "status": "match" }
  ],
  "edges": [
    { "from": "step-1", "to": "step-2", "status": "ordered" }
  ]
}
```

- `nodes` must include every live observation/step.
- `edges` must reflect the execution order.
- `status` values: `match`, `out-of-sequence`, `dynamic-runtime`.

#### 2. Mermaid Flowchart (Visual Depiction)

Provide a vertical `graph TD` Mermaid flowchart.

Color-code nodes using inline styles:
- **Emerald Green `#10B981`** — matches session export template
- **Crimson Red `#EF4444`** — out of sequence / threshold failure
- **Amber Orange `#F59E0B`** — dynamic runtime tool call

Example:
```mermaid
graph TD
    A[Step 1: Input] --> B[Step 2: Tool Call]
    B --> C[Step 3: Output]
    style A fill:#10B981
    style B fill:#F59E0B
    style C fill:#10B981
```

#### 3. Validation Scorecard (Differential Metric Report)

Provide a Markdown table with these exact columns:

| Metric Vector | Live Trace Value | Independent Record Target | Status | Runtime Deviation |
|---|---|---|---|---|
| Node Sequence Count | [count] | [count] | ✅ MATCH / ❌ MISMATCH | [difference] |
| Execution Latency | [seconds] | [max seconds] | ✅ PASS / ❌ REGRESSION | [deviation] |
| Token Cost Barrier | [cost] | [max cost] | ✅ PASS / ❌ OVER-BUDGET | [deviation] |

End with this explicit label on its own line:

```
Overall Execution Validation State [OPTIMAL | ATTENTION REQUIRED | REGRESSION THRESHOLD BREACHED]
```

Choose the label based on the worst individual status:
- All `✅ MATCH` / `✅ PASS` → `OPTIMAL`
- Any `❌ MISMATCH` or `❌ REGRESSION` → `ATTENTION REQUIRED`
- Any `❌ OVER-BUDGET` with significant deviation → `REGRESSION THRESHOLD BREACHED`

## Pitfalls
- `@langfuse/cli` must be invoked as `npx @langfuse/cli ...`; `@file:` references are invalid.
- The baseline file must be valid JSON from `npx @langfuse/cli api observations list --json`, which returns `{"body": {"data": [...]}}`. Do not expect a top-level `traces` array.
- Latency and cost comparisons require numeric fields in both the live trace and baseline export; if a field is missing, report `N/A` in the scorecard. Observation-level exports rarely include token/cost fields, so cost comparisons will typically be `N/A`.
- When validating the scorecard programmatically, the markdown table includes a separator row (`|---|`). Count data rows as the non-separator, non-header pipe-prefixed lines; there should be exactly 3 data rows.
- Mermaid charts render in Hermes desktop via `::preview{file="..."}` if saved to an `.html` wrapper; inline Mermaid code blocks may not render everywhere.

## Step 5: Write Artifacts to Disk

Write the three emitted artifacts to files in the **same directory** as the baseline export JSON. Use these filenames, replacing `<trace_id>` with the live trace ID:

- `trace_graph_<trace_id>.json` — the JSON graph
- `trace_flowchart_<trace_id>.mmd` — the Mermaid flowchart
- `trace_scorecard_<trace_id>.md` — the validation scorecard

Write each file using `write_file`.

## Verification

After computing, verify:
- The JSON graph block parses as valid JSON.
- The Mermaid `graph TD` block contains only supported node/edge syntax.
- The scorecard table has exactly 5 columns and 3 data rows (header + separator + 3 data rows = 5 pipe-prefixed lines total).
- The final status label matches one of the three allowed values.
- All three artifact files exist on disk in the baseline directory, are non-empty, and the `.json` artifact parses as valid JSON.
