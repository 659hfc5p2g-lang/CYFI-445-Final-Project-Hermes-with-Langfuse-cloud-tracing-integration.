---
name:trace analyzer
description:"instructs Hermes to orchestrate a CLI data loop, cross reference a live trace against an independent record & output a machine readable graph, a visual flowchart, and a validation report."
version:"1.0.0"
---

#Trace Analyzer command loop

##Step 1 -Intercept & Trigger
when I type /trace-analyze --id<trace_id> --baseline<filepath>, Instantly start the tool calling process using your system access shell.

##Step 2:The tool calling loop
1.run 'npx @langfuse/cli api observations list --trace-id<trace_id> --json' to get the live graph data
2.run 'npx @langfuse/cli api scores list --trace-id<trace_id> --json' to get the live graph data
3.open and read the local langfuse session export JSON file in the '--baseline' path.

##Step 3:Compute & Compare
1. Isolate the "traces" array inside the session export to use as the golden sequence template.
2. Compare the new live trace steps against the session export history to check for out of order steps.
3. Calculate if the new runs latency or cost has increased compared to the baseline session averages.

##Step 4-Output the required artifacts.

### 1. JSON Graph (Machine-Readable Topology)
Provide a raw code block containing a consolidated, structural JSON payload that maps the live trace node and edge array variables.

### 2. Mermaid Flowchart (Visual Depiction)
Provide a clean, valid vertical Mermaid.js flowchart (`graph TD`) mapping out the step execution order. Color-code the nodes based on performance
- Matches Session Export Template Emerald Green (`#10B981`)
- Out of Sequence  Threshold Failure Crimson Red (`#EF4444`)
- Dynamic Runtime Tool Call AmberOrange (`#F59E0B`)

### 3. Validation Scorecard (Differential Metric Report)
Provide a clean Markdown data table with these exact columns

 Metric Vector  Live Trace Value  Independent Record Target  Status  Runtime Deviation 
 ---  ---  ---  ---  --- 
 Node Sequence Count [Count from trace]  [Count from baseline export]  [✅ MATCH  ❌ MISMATCH]  [Difference] 
 Execution Latency  [Time from trace]   [Max time from export]      [✅ PASS  ❌ REGRESSION]  [Deviation in seconds] 
 Token Cost Barrier [Cost from trace]   [Max cost from export]      [✅ PASS  ❌ OVER-BUDGET] [Cost deviation] 

End the report with the explicit status evaluation label
Overall Execution Validation State [OPTIMAL  ATTENTION REQUIRED  REGRESSION THRESHOLD BREACHED]