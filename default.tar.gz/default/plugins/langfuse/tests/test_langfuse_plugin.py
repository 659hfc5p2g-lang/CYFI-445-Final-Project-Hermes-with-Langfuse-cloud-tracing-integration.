"""Tests for the langfuse plugin (formerly bundled with Hermes as observability/langfuse)."""
from __future__ import annotations

import importlib
import json
import logging
import sys
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace

import pytest


# ---------------------------------------------------------------------------
# Plugin discovery: langfuse is opt-in (not loaded unless explicitly enabled).
# This guards against someone accidentally re-introducing a per-hook
# load_config() gate or making the plugin auto-load.
# ---------------------------------------------------------------------------

class TestDiscovery:
    def test_installed_plugin_is_discovered_as_standalone_opt_in(self, tmp_path, monkeypatch):
        """An installed copy is found under the profile's plugins/ dir but NOT loaded by default."""
        import shutil

        from hermes_cli import plugins as plugins_mod

        # Isolated HERMES_HOME so we don't read the developer's config.yaml.
        home = tmp_path / ".hermes"
        home.mkdir()
        monkeypatch.setenv("HERMES_HOME", str(home))
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        root = Path(__file__).resolve().parents[1]
        shutil.copytree(root, home / "plugins" / "langfuse", ignore=shutil.ignore_patterns("tests", "__pycache__"))

        manager = plugins_mod.PluginManager()
        manager.discover_and_load()

        loaded = manager._plugins.get("langfuse")
        assert loaded is not None, "plugin not discovered"
        # Opt-in default: no config.yaml means nothing enabled.
        assert loaded.enabled is False
        assert "not enabled" in (loaded.error or "").lower()


class TestRegister:
    class _Ctx:
        def __init__(self):
            self.hooks = []

        def register_hook(self, name, fn):
            self.hooks.append(name)

    def test_registers_every_hook_on_a_core_without_the_bundled_copy(self, monkeypatch):
        plugin = importlib.import_module("langfuse_plugin")
        monkeypatch.setattr(plugin, "_core_ships_langfuse", lambda: False)
        ctx = self._Ctx()
        plugin.register(ctx)
        assert set(ctx.hooks) == {
            "pre_api_request", "post_api_request", "api_request_error", "pre_llm_call", "post_llm_call",
            "pre_tool_call", "post_tool_call", "on_session_finalize", "on_session_end",
            "subagent_start", "subagent_stop",
        }

    def test_stays_inert_on_a_core_that_still_bundles_langfuse(self, monkeypatch, tmp_path):
        """The bundled copy also answers to ``langfuse`` in plugins.enabled: both registering would
        send every trace twice."""
        import plugins as core_plugins

        plugin = importlib.import_module("langfuse_plugin")
        bundled = tmp_path / "core_plugins"
        (bundled / "observability" / "langfuse").mkdir(parents=True)
        (bundled / "observability" / "langfuse" / "plugin.yaml").write_text("name: langfuse\n")
        monkeypatch.setattr(core_plugins, "__path__", [str(bundled)])
        ctx = self._Ctx()
        plugin.register(ctx)
        assert ctx.hooks == []


# ---------------------------------------------------------------------------
# Runtime gate: _get_langfuse() returns None and caches _INIT_FAILED when
# credentials are missing. Guards against regressing toward the rejected
# per-hook load_config() design.
# ---------------------------------------------------------------------------

class TestRuntimeGate:
    def _fresh_plugin(self):
        """Import the plugin module fresh (clears any cached client)."""
        mod_name = "langfuse_plugin"
        sys.modules.pop(mod_name, None)
        return importlib.import_module(mod_name)

    def test_get_langfuse_returns_none_without_credentials(self, monkeypatch):
        for k in (
            "HERMES_LANGFUSE_PUBLIC_KEY", "HERMES_LANGFUSE_SECRET_KEY",
            "LANGFUSE_PUBLIC_KEY", "LANGFUSE_SECRET_KEY",
        ):
            monkeypatch.delenv(k, raising=False)

        langfuse_plugin = self._fresh_plugin()
        assert langfuse_plugin._get_langfuse() is None

    def test_missing_sdk_logs_one_warning(self, monkeypatch, caplog):
        langfuse_plugin = self._fresh_plugin()
        monkeypatch.setattr(langfuse_plugin, "Langfuse", None)
        langfuse_plugin._LANGFUSE_CLIENT = None

        with caplog.at_level(logging.WARNING, logger=langfuse_plugin.__name__):
            assert langfuse_plugin._get_langfuse() is None
            assert langfuse_plugin._get_langfuse() is None

        messages = [record.getMessage() for record in caplog.records]
        assert len(messages) == 1


# ---------------------------------------------------------------------------
# Hooks are inert when the client is unavailable.
# ---------------------------------------------------------------------------

class TestHooksInert:
    def test_hooks_noop_without_client(self, monkeypatch):
        """All 6 hooks must return without raising when _get_langfuse() is None."""
        for k in (
            "HERMES_LANGFUSE_PUBLIC_KEY", "HERMES_LANGFUSE_SECRET_KEY",
            "LANGFUSE_PUBLIC_KEY", "LANGFUSE_SECRET_KEY",
        ):
            monkeypatch.delenv(k, raising=False)

        sys.modules.pop("langfuse_plugin", None)
        import importlib
        mod = importlib.import_module("langfuse_plugin")

        # Each hook should just return; no exceptions.
        mod.on_pre_llm_call(task_id="t", session_id="s", messages=[{"role": "user", "content": "hi"}])
        mod.on_pre_llm_request(task_id="t", session_id="s", api_call_count=1, request_messages=[])
        mod.on_post_llm_call(task_id="t", session_id="s", api_call_count=1)
        mod.on_pre_tool_call(tool_name="read_file", args={}, task_id="t", session_id="s")
        mod.on_post_tool_call(tool_name="read_file", args={}, result="ok", task_id="t", session_id="s")


class TestPayloadSanitization:
    def test_safe_value_redacts_base64_data_uri_instead_of_truncating(self):
        sys.modules.pop("langfuse_plugin", None)
        import importlib
        mod = importlib.import_module("langfuse_plugin")

        payload = "data:image/png;base64," + ("a" * 20000)
        result = mod._safe_value(payload)

        assert result == {
            "type": "data_uri",
            "media_type": "image/png",
            "omitted": True,
            "length": len(payload),
        }

    def test_serialize_messages_redacts_data_uri_parts(self):
        sys.modules.pop("langfuse_plugin", None)
        import importlib
        mod = importlib.import_module("langfuse_plugin")

        payload = "data:image/jpeg;base64," + ("b" * 20000)
        serialized = mod._serialize_messages([
            {"role": "user", "content": [{"type": "image_url", "image_url": {"url": payload}}]}
        ])

        assert serialized[0]["content"][0]["image_url"]["url"] == {
            "type": "data_uri",
            "media_type": "image/jpeg",
            "omitted": True,
            "length": len(payload),
        }


# ---------------------------------------------------------------------------
# End-to-end collision regression: two turns of ONE gateway session must not
# share trace state.  The helper-level tests above prove _trace_key returns
# distinct keys; this drives the real pre/post hooks to prove the keys are
# actually threaded through so the second turn gets its own root trace.
#
# Gateway reality this reproduces:
#   * task_id == session_id for every turn        (gateway/run.py)
#   * turn_id is unique per turn                   (turn_context.py)
#   * api_call_count resets to 1 each turn         (conversation_loop.py)
#
# Before the turn/request scoping, _trace_key collapsed to the constant
# session_id.  That worked only because _finish_trace pops the key on a clean
# turn end.  When turn 1 does NOT finalize (interrupted, tool-only final step,
# or empty final content), its state lingered under session_id and turn 2
# silently merged into turn 1's trace instead of opening its own.
# ---------------------------------------------------------------------------


class TestTurnTraceIsolation:
    def _fresh_plugin(self):
        sys.modules.pop("langfuse_plugin", None)
        return importlib.import_module("langfuse_plugin")

    @staticmethod
    def _fake_client(started):
        """A minimal Langfuse stand-in that records each root trace opened.

        ``_start_root_trace`` calls ``create_trace_id`` then opens a root via
        ``start_as_current_observation(...)`` (a context manager whose
        ``__enter__`` returns the root span).  We record one entry per root
        actually opened so the test can count distinct traces.
        """

        class _Span:
            def update(self, **kw):
                pass

            def end(self, **kw):
                pass

            def set_trace_io(self, **kw):
                pass

            def start_observation(self, **kw):
                return _Span()

        class _RootCM:
            def __enter__(self):
                return _Span()

            def __exit__(self, *exc):
                return False

        class _Client:
            def create_trace_id(self, seed=None):
                return f"trace::{seed}"

            def start_as_current_observation(self, **kw):
                started.append(kw.get("trace_context", {}).get("trace_id"))
                return _RootCM()

            def start_observation(self, **kw):  # the detached root the plugin opens
                return self.start_as_current_observation(**kw).__enter__()

            def flush(self):
                pass

        return _Client()

    def _run_turn(self, mod, *, session, turn_n, finalize):
        """Drive one turn through the request-scoped hooks the gateway fires."""
        task_id = session  # gateway sets task_id == session_id
        turn_id = f"{session}:{task_id}:turn{turn_n}"
        api_call_count = 1  # resets every turn
        api_request_id = f"{turn_id}:api:{api_call_count}"

        mod.on_pre_llm_request(
            task_id=task_id,
            session_id=session,
            model="m",
            provider="p",
            api_mode="chat",
            api_call_count=api_call_count,
            request_messages=[{"role": "user", "content": "hi"}],
            turn_id=turn_id,
            api_request_id=api_request_id,
        )
        # finalize=False => leave a tool call on the final response so
        # _finish_trace is skipped and the turn's state lingers.
        mod.on_post_llm_call(
            task_id=task_id,
            session_id=session,
            model="m",
            provider="p",
            api_mode="chat",
            api_call_count=api_call_count,
            assistant_content_chars=5 if finalize else 0,
            assistant_tool_call_count=0 if finalize else 1,
            usage={"input_tokens": 10, "output_tokens": 5},
            turn_id=turn_id,
            api_request_id=api_request_id,
        )

    def test_unfinalized_turn_does_not_capture_next_turn(self, monkeypatch):
        """A turn that never finalizes must not absorb the following turn."""
        mod = self._fresh_plugin()
        started: list = []
        monkeypatch.setattr(mod, "_get_langfuse", lambda: self._fake_client(started))
        monkeypatch.setattr(mod, "_end_observation", lambda *a, **k: None)
        mod._TRACE_STATE.clear()

        # Turn 1 ends without finalizing (its final step still has a tool call).
        self._run_turn(mod, session="sess-iso", turn_n=1, finalize=False)
        # Turn 2 is a normal, fully finalizing turn in the SAME session.
        self._run_turn(mod, session="sess-iso", turn_n=2, finalize=True)

        # Each turn opened its OWN root trace.  On the pre-fix code the second
        # turn reused turn 1's lingering state and only one trace was opened.
        assert len(started) == 2
        # The Langfuse trace identity itself must be turn-scoped too.  A distinct
        # in-process state key with a stable session/task-derived remote trace ID
        # still merges every room reply into one Cloud trace.
        assert len(set(started)) == 2

        # Turn 2 finalized and was popped by _finish_trace; only turn 1's
        # (non-finalizing) state lingers.  Assert the surviving key is turn 1's
        # and that turn 2 never merged into it — `all(...)` over an empty set
        # would pass vacuously, so pin the exact surviving key instead.
        keys = list(mod._TRACE_STATE.keys())
        assert len(keys) == 1
        assert "turn1" in keys[0]
        assert "turn2" not in keys[0]

    def test_pre_and_post_hooks_share_one_key_within_a_turn(self, monkeypatch):
        """turn_id is preferred over api_request_id so the turn-scoped
        post_llm_call (which carries no api_request_id) still resolves to the
        same key as the request-scoped pre/post_api_request hooks.  If the
        ordering were reversed, finalization would silently break."""
        mod = self._fresh_plugin()
        turn_id = "S:T:turnX"
        api_request_id = f"{turn_id}:api:1"

        k_pre_api = mod._trace_key("T", "S", turn_id=turn_id, api_request_id=api_request_id)
        k_post_api = mod._trace_key("T", "S", turn_id=turn_id, api_request_id=api_request_id)
        k_post_turn = mod._trace_key("T", "S", turn_id=turn_id, api_request_id="")

        assert k_pre_api == k_post_api == k_post_turn

    def test_non_finalizing_turns_do_not_grow_state_unboundedly(self, monkeypatch):
        """Per-turn keys mean a turn that never finalizes leaves a lingering
        entry.  Without a cap that grows once per non-finalizing turn forever;
        the LRU eviction must bound _TRACE_STATE at _MAX_TRACE_STATE.
        """
        mod = self._fresh_plugin()
        started: list = []
        monkeypatch.setattr(mod, "_get_langfuse", lambda: self._fake_client(started))
        monkeypatch.setattr(mod, "_end_observation", lambda *a, **k: None)
        monkeypatch.setattr(mod, "_MAX_TRACE_STATE", 8)
        mod._TRACE_STATE.clear()

        # Far more non-finalizing turns than the cap.
        for n in range(50):
            self._run_turn(mod, session="sess-leak", turn_n=n, finalize=False)

        assert len(mod._TRACE_STATE) <= 8
        # The survivors are the most-recently-updated turns (LRU eviction).
        surviving = sorted(int(k.rsplit("turn", 1)[1]) for k in mod._TRACE_STATE)
        assert surviving == list(range(42, 50))

    def test_a_turn_finished_on_another_thread_detaches_nothing(self, monkeypatch):
        """Hermes fires a turn's pre and post hooks on different worker threads (hermes-agent#95057).

        The root used to be opened with ``start_as_current_observation(...).__enter__()``, which
        pushes an OTEL contextvars token, and exited later from ``_finish_trace`` on another thread,
        where OTEL cannot pop it: every turn logged "Failed to detach context". The fake mirrors
        that rule: a current-span context exited on a different thread than it was entered on is
        recorded as a cross-context detach. The root must end with none.
        """
        import threading

        mod = self._fresh_plugin()
        monkeypatch.setattr(mod, "_end_observation", lambda *a, **k: None)
        mod._TRACE_STATE.clear()
        cross_context: list = []
        ended: list = []

        class _S:
            def update(self, **kw): pass
            def update_trace(self, **kw): pass
            def end(self, **kw): ended.append(threading.current_thread())
            def start_observation(self, **kw): return _S()

        class _CurrentSpanCM:
            # Thread objects, not get_ident(): a joined thread's ident is reused by the next one.
            def __enter__(self):
                self._entered_on = threading.current_thread()
                return _S()

            def __exit__(self, *exc):
                if threading.current_thread() is not self._entered_on:
                    cross_context.append("Failed to detach context")
                return False

        class _Client:
            def create_trace_id(self, seed=None): return f"trace::{seed}"
            def start_as_current_observation(self, **kw): return _CurrentSpanCM()
            def start_observation(self, **kw): return _S()
            def flush(self): pass

        monkeypatch.setattr(mod, "_get_langfuse", lambda: _Client())
        session, turn_id = "sess-threads", "sess-threads:sess-threads:turn1"
        common = dict(task_id=session, session_id=session, model="m", provider="p", api_mode="chat",
                      api_call_count=1, turn_id=turn_id, api_request_id=f"{turn_id}:api:1")
        opener = threading.Thread(target=lambda: mod.on_pre_llm_request(
            request_messages=[{"role": "user", "content": "hi"}], **common))
        opener.start(); opener.join()
        finisher = threading.Thread(target=lambda: mod.on_post_llm_call(
            assistant_content_chars=5, assistant_tool_call_count=0,
            usage={"input_tokens": 10, "output_tokens": 5}, **common))
        finisher.start(); finisher.join()

        assert ended, "the root span was never ended"
        assert cross_context == []


# ---------------------------------------------------------------------------
# Placeholder-credential guard (#23823).
#
# Regression coverage for the silent-failure bug: when an operator leaves
# HERMES_LANGFUSE_PUBLIC_KEY / SECRET_KEY at a template value like
# "placeholder", "test-key", or "your-langfuse-key", the SDK accepts the
# credentials at construction time (it does no server-side validation
# eagerly) but drops every trace at flush time, with no signal in the
# Hermes logs.  The fix in `_get_langfuse()` validates the documented
# `pk-lf-` / `sk-lf-` prefix Langfuse always issues, surfaces a one-shot
# warning naming the offending env var(s), and short-circuits via the
# same `_INIT_FAILED` path used for missing credentials so subsequent
# hook invocations don't re-log.
# ---------------------------------------------------------------------------


class _FakeLangfuse:
    """Stand-in for the real :class:`langfuse.Langfuse` so tests don't
    need the optional ``langfuse`` SDK installed.  The plugin's runtime
    gate refuses to proceed past ``if Langfuse is None`` when the SDK
    is missing, which would short-circuit before the placeholder check
    can fire.  Patching ``plugin.Langfuse`` with this class lets the
    placeholder validator exercise its full code path."""

    instances: list[_FakeLangfuse] = []

    def __init__(self, **kwargs):
        self.kwargs = kwargs
        _FakeLangfuse.instances.append(self)


class TestPlaceholderKeyDetection:
    LOGGER_NAME = "langfuse_plugin"

    def _fresh_plugin(self, monkeypatch=None):
        mod_name = "langfuse_plugin"
        sys.modules.pop(mod_name, None)
        mod = importlib.import_module(mod_name)
        if monkeypatch is not None:
            # Pretend the SDK is installed so `_get_langfuse()` actually
            # reaches the placeholder check.  Real SDK calls are never
            # made because the placeholder/missing-credentials paths
            # return before constructing a client.
            _FakeLangfuse.instances.clear()
            monkeypatch.setattr(mod, "Langfuse", _FakeLangfuse, raising=False)
        return mod

    @staticmethod
    def _clear_env(monkeypatch):
        for k in (
            "HERMES_LANGFUSE_PUBLIC_KEY", "HERMES_LANGFUSE_SECRET_KEY",
            "LANGFUSE_PUBLIC_KEY", "LANGFUSE_SECRET_KEY",
            "HERMES_LANGFUSE_BASE_URL", "LANGFUSE_BASE_URL",
        ):
            monkeypatch.delenv(k, raising=False)

    # -- helper unit tests (no SDK stub needed: these don't go through
    #    _get_langfuse, they exercise the pure-Python helpers directly) ------


    def test_validate_langfuse_key_accepts_documented_prefix(self, monkeypatch):
        self._clear_env(monkeypatch)
        plugin = self._fresh_plugin()
        assert plugin._validate_langfuse_key(
            "HERMES_LANGFUSE_PUBLIC_KEY", "pk-lf-...-xyz"
        ) is None
        assert plugin._validate_langfuse_key(
            "HERMES_LANGFUSE_SECRET_KEY", "sk-lf-...-xyz"
        ) is None

    @pytest.mark.parametrize(("env_name", "value"), [
        ("HERMES_LANGFUSE_PUBLIC_KEY", "pk-lf-..."), ("HERMES_LANGFUSE_SECRET_KEY", "sk-lf-***"),
        ("HERMES_LANGFUSE_SECRET_KEY", "sk-lf-"), ("HERMES_LANGFUSE_PUBLIC_KEY", "***"),
        ("HERMES_LANGFUSE_SECRET_KEY", "sk-lf-...-key"), ("HERMES_LANGFUSE_PUBLIC_KEY", "***"),
    ])
    def test_validate_langfuse_key_rejects_right_prefix_templates(self, monkeypatch, env_name, value):
        """The docs' own ``pk-lf-...`` passes a prefix-only check and then drops every
        trace at flush time (hermes-agent#51399)."""
        self._clear_env(monkeypatch)
        msg = self._fresh_plugin()._validate_langfuse_key(env_name, value)
        assert msg is not None and env_name in msg and "template" in msg

    def test_validate_langfuse_key_accepts_uuid_shaped_keys(self, monkeypatch):
        """Issued remainders are hex + dashes; no template fragment can match them."""
        self._clear_env(monkeypatch)
        plugin = self._fresh_plugin()
        assert plugin._validate_langfuse_key("HERMES_LANGFUSE_PUBLIC_KEY", "pk-lf-...eeff") is None
        assert plugin._validate_langfuse_key("HERMES_LANGFUSE_SECRET_KEY", "sk-lf-...89ab") is None


    # -- end-to-end _get_langfuse() behaviour --------------------------------
    # These tests pass `monkeypatch` to _fresh_plugin() so the helper can
    # stub out `Langfuse` (the optional SDK).  Without that, every call
    # short-circuits at `if Langfuse is None` before reaching the
    # placeholder validator — masking the very behaviour we're testing.

    def test_placeholder_public_key_warns_and_skips(self, monkeypatch, caplog):
        self._clear_env(monkeypatch)
        monkeypatch.setenv("HERMES_LANGFUSE_PUBLIC_KEY", "placeholder")
        monkeypatch.setenv("HERMES_LANGFUSE_SECRET_KEY", "sk-lf-...-xyz")
        plugin = self._fresh_plugin(monkeypatch)
        with caplog.at_level(logging.WARNING, logger=self.LOGGER_NAME):
            assert plugin._get_langfuse() is None
        text = caplog.text
        assert "HERMES_LANGFUSE_PUBLIC_KEY" in text
        assert "'placeholder'" in text
        assert "pk-lf-" in text
        # The valid secret value must NOT appear (the var NAME does, in
        # the "or unset ..." hint, but the value preview shouldn't).
        assert "'sk-lf-" not in text
        # Never constructed the SDK client — short-circuited before that.
        assert _FakeLangfuse.instances == []

    def test_placeholder_secret_key_warns_and_skips(self, monkeypatch, caplog):
        self._clear_env(monkeypatch)
        monkeypatch.setenv("HERMES_LANGFUSE_PUBLIC_KEY", "pk-lf-...-xyz")
        monkeypatch.setenv("HERMES_LANGFUSE_SECRET_KEY", "test-key")
        plugin = self._fresh_plugin(monkeypatch)
        with caplog.at_level(logging.WARNING, logger=self.LOGGER_NAME):
            assert plugin._get_langfuse() is None
        text = caplog.text
        assert "HERMES_LANGFUSE_SECRET_KEY" in text
        assert "'test-key'" in text
        assert "sk-lf-" in text
        # The valid public value must NOT appear.
        assert "'pk-lf-" not in text
        assert _FakeLangfuse.instances == []

    def test_both_placeholders_one_warning_with_both_keys(self, monkeypatch, caplog):
        self._clear_env(monkeypatch)
        monkeypatch.setenv("HERMES_LANGFUSE_PUBLIC_KEY", "placeholder")
        monkeypatch.setenv("HERMES_LANGFUSE_SECRET_KEY", "placeholder")
        plugin = self._fresh_plugin(monkeypatch)
        with caplog.at_level(logging.WARNING, logger=self.LOGGER_NAME):
            assert plugin._get_langfuse() is None
        warnings = [r for r in caplog.records if r.levelname == "WARNING"
                    and r.name == self.LOGGER_NAME]
        assert len(warnings) == 1, (
            f"Expected a single combined warning; got {len(warnings)}:\n"
            + "\n".join(r.getMessage() for r in warnings)
        )
        text = warnings[0].getMessage()
        assert "HERMES_LANGFUSE_PUBLIC_KEY" in text
        assert "HERMES_LANGFUSE_SECRET_KEY" in text

    def test_repeated_calls_do_not_re_warn(self, monkeypatch, caplog):
        """The cached ``_INIT_FAILED`` sentinel must short-circuit
        subsequent calls so each hook invocation isn't a fresh log
        line — otherwise a busy gateway will spam the operator's
        terminal."""
        self._clear_env(monkeypatch)
        monkeypatch.setenv("HERMES_LANGFUSE_PUBLIC_KEY", "placeholder")
        monkeypatch.setenv("HERMES_LANGFUSE_SECRET_KEY", "placeholder")
        plugin = self._fresh_plugin(monkeypatch)
        with caplog.at_level(logging.WARNING, logger=self.LOGGER_NAME):
            for _ in range(15):
                assert plugin._get_langfuse() is None
        warnings = [r for r in caplog.records if r.levelname == "WARNING"
                    and r.name == self.LOGGER_NAME]
        assert len(warnings) == 1, (
            f"Warning fired {len(warnings)} times across 15 calls; "
            "expected 1 (cached via _INIT_FAILED)"
        )

    @pytest.mark.parametrize(("public", "secret"), [
        ("custom-public-key", "custom-secret-key"), ("ollama", "sk-..."),
        ("sk-lf-...12ab", "pk-lf-...5b4a"),  # swapped
    ])
    def test_custom_endpoint_builds_but_warns_on_wrong_prefix(self, monkeypatch, caplog, public, secret):
        """A custom Langfuse-compatible endpoint may issue keys without the Cloud prefix and
        authenticates them itself (hermes-agent#72484), so the client is built. Self-hosted
        Langfuse issues pk-lf-/sk-lf- keys too, so a wrong prefix (the `ollama` / `sk-...` /
        swapped keys of hermes-agent#51399) still warns once instead of dying silently at flush."""
        self._clear_env(monkeypatch)
        monkeypatch.setenv("HERMES_LANGFUSE_BASE_URL", "https://langfuse.mycorp.example")
        monkeypatch.setenv("HERMES_LANGFUSE_PUBLIC_KEY", public)
        monkeypatch.setenv("HERMES_LANGFUSE_SECRET_KEY", secret)
        plugin = self._fresh_plugin(monkeypatch)
        with caplog.at_level(logging.WARNING, logger=self.LOGGER_NAME):
            for _ in range(3):
                assert plugin._get_langfuse() is not None
        warnings = [r.getMessage() for r in caplog.records if r.name == self.LOGGER_NAME]
        assert len(warnings) == 1 and "expected 'pk-lf-' prefix" in warnings[0], warnings
        assert "NOT be emitted" not in warnings[0]
        assert _FakeLangfuse.instances[0].kwargs["public_key"] == public

    def test_custom_endpoint_still_refuses_template_keys(self, monkeypatch, caplog):
        self._clear_env(monkeypatch)
        monkeypatch.setenv("HERMES_LANGFUSE_BASE_URL", "https://langfuse.mycorp.example")
        monkeypatch.setenv("HERMES_LANGFUSE_PUBLIC_KEY", "pk-lf-...")
        monkeypatch.setenv("HERMES_LANGFUSE_SECRET_KEY", "sk-lf-...12ab")
        plugin = self._fresh_plugin(monkeypatch)
        with caplog.at_level(logging.WARNING, logger=self.LOGGER_NAME):
            assert plugin._get_langfuse() is None
        warnings = [r.getMessage() for r in caplog.records if r.name == self.LOGGER_NAME]
        assert len(warnings) == 1 and "template" in warnings[0] and "NOT be emitted" in warnings[0]
        assert _FakeLangfuse.instances == []

    @pytest.mark.parametrize(("base_url", "guarded"), [
        ("https://cloud.langfuse.com", True), ("https://us.cloud.langfuse.com.", True),
        ("https://evil-langfuse.com", False), ("https://langfuse.com.evil.example", False),
    ])
    def test_prefix_guard_scoped_to_langfuse_cloud_hosts(self, monkeypatch, base_url, guarded):
        self._clear_env(monkeypatch)
        monkeypatch.setenv("HERMES_LANGFUSE_BASE_URL", base_url)
        monkeypatch.setenv("HERMES_LANGFUSE_PUBLIC_KEY", "custom-public-key")
        monkeypatch.setenv("HERMES_LANGFUSE_SECRET_KEY", "custom-secret-key")
        assert (self._fresh_plugin(monkeypatch)._get_langfuse() is None) is guarded

    def test_missing_secret_key_warns_once_and_skips(self, monkeypatch, caplog):
        """Placeholder public key + unset secret used to fail with zero log output
        (hermes-agent#98631): the empty branch runs before the placeholder guard."""
        self._clear_env(monkeypatch)
        monkeypatch.setenv("HERMES_LANGFUSE_PUBLIC_KEY", "your-public-key-here")
        plugin = self._fresh_plugin(monkeypatch)
        with caplog.at_level(logging.WARNING, logger=self.LOGGER_NAME):
            for _ in range(3):
                assert plugin._get_langfuse() is None
        warnings = [r.getMessage() for r in caplog.records if r.name == self.LOGGER_NAME]
        assert len(warnings) == 1
        assert "missing credentials (HERMES_LANGFUSE_SECRET_KEY)" in warnings[0]
        assert "traces will NOT be emitted" in warnings[0]
        assert _FakeLangfuse.instances == []

    @pytest.mark.parametrize(("service_name", "resource_attrs", "expected"), [
        (None, "", "hermes-agent"), (None, "service.name=my-agent", None), ("my-agent", "", "my-agent"),
    ])
    def test_client_build_defaults_otel_service_name(self, monkeypatch, service_name, resource_attrs, expected):
        """Without it the SDK's OTel resource exports service.name=unknown_service
        (hermes-agent#58322); an operator-set service.name must not be overridden. The SDK's
        TracerProvider reads the env once, in Langfuse(); the default must not outlive that call,
        or every terminal-tool command and MCP server inherits OTEL_SERVICE_NAME=hermes-agent."""
        import os
        self._clear_env(monkeypatch)
        monkeypatch.setenv("OTEL_SERVICE_NAME", "restore-me")  # so teardown undoes any leak
        monkeypatch.delenv("OTEL_SERVICE_NAME")
        if service_name:
            monkeypatch.setenv("OTEL_SERVICE_NAME", service_name)
        monkeypatch.setenv("OTEL_RESOURCE_ATTRIBUTES", resource_attrs)
        monkeypatch.setenv("HERMES_LANGFUSE_PUBLIC_KEY", "pk-lf-...-xyz")
        monkeypatch.setenv("HERMES_LANGFUSE_SECRET_KEY", "sk-lf-...-xyz")
        plugin = self._fresh_plugin(monkeypatch)
        seen = []
        monkeypatch.setattr(plugin, "Langfuse", lambda **kw: seen.append(os.environ.get("OTEL_SERVICE_NAME")) or _FakeLangfuse(**kw))
        assert plugin._get_langfuse() is not None
        assert seen == [expected]  # what the SDK's resource captured
        assert os.environ.get("OTEL_SERVICE_NAME") == service_name  # process env left as it was


class TestRequestMessageCoercion:
    def test_prefers_request_messages_then_messages_then_history_then_user_message(self):
        sys.modules.pop("langfuse_plugin", None)
        mod = importlib.import_module("langfuse_plugin")

        assert mod._coerce_request_messages(
            request_messages=[{"role": "system", "content": "s"}],
            messages=[{"role": "user", "content": "m"}],
            conversation_history=[{"role": "user", "content": "h"}],
            user_message="u",
        ) == [{"role": "system", "content": "s"}]
        assert mod._coerce_request_messages(
            messages=[{"role": "user", "content": "m"}],
            conversation_history=[{"role": "user", "content": "h"}],
            user_message="u",
        ) == [{"role": "user", "content": "m"}]
        assert mod._coerce_request_messages(
            conversation_history=[{"role": "user", "content": "h"}],
            user_message="u",
        ) == [{"role": "user", "content": "h"}]
        assert mod._coerce_request_messages(user_message="u") == [{"role": "user", "content": "u"}]


class TestAssistantMessageSerialization:
    def test_serialize_assistant_message_prefers_reasoning(self):
        sys.modules.pop("langfuse_plugin", None)
        mod = importlib.import_module("langfuse_plugin")

        message = SimpleNamespace(
            content="answer",
            reasoning="primary reasoning",
            reasoning_content="fallback reasoning",
            reasoning_details=[{"type": "summary", "text": "structured reasoning"}],
        )

        assert mod._serialize_assistant_message(message)["reasoning"] == "primary reasoning"

    def test_serialize_assistant_message_uses_reasoning_content_when_reasoning_absent(self):
        sys.modules.pop("langfuse_plugin", None)
        mod = importlib.import_module("langfuse_plugin")

        message = SimpleNamespace(
            content="answer",
            reasoning=None,
            reasoning_content="provider scratchpad",
            reasoning_details=[{"type": "summary", "text": "structured reasoning"}],
        )

        assert mod._serialize_assistant_message(message)["reasoning"] == "provider scratchpad"

    def test_serialize_assistant_message_uses_structured_reasoning_details(self):
        sys.modules.pop("langfuse_plugin", None)
        mod = importlib.import_module("langfuse_plugin")

        reasoning_details = [
            {"type": "summary", "text": "checked tools"},
            {"type": "encrypted_content", "encrypted_content": b"opaque"},
        ]
        message = SimpleNamespace(
            content="answer",
            reasoning=None,
            reasoning_content=None,
            reasoning_details=reasoning_details,
        )

        assert mod._serialize_assistant_message(message)["reasoning"] == [
            {"type": "summary", "text": "checked tools"},
            {"type": "encrypted_content", "encrypted_content": {"type": "bytes", "len": 6}},
        ]

    def test_serialize_assistant_message_without_reasoning_fields_sets_none(self):
        sys.modules.pop("langfuse_plugin", None)
        mod = importlib.import_module("langfuse_plugin")

        message = SimpleNamespace(content="answer")

        assert mod._serialize_assistant_message(message)["reasoning"] is None


class TestToolCallOutputBackfill:
    def test_post_tool_call_backfills_matching_turn_tool_call_output(self, monkeypatch):
        sys.modules.pop("langfuse_plugin", None)
        mod = importlib.import_module("langfuse_plugin")

        observation = object()
        state = mod.TraceState(trace_id="trace-1", root_span=None)
        state.tools["call-1"] = observation
        state.turn_tool_calls.append({
            "id": "call-1",
            "type": "function",
            "name": "web_extract",
            "arguments": '{"urls": ["https://example.com"]}',
            "function": {
                "name": "web_extract",
                "arguments": '{"urls": ["https://example.com"]}',
            },
        })

        task_key = mod._trace_key("task-1", "session-1")
        monkeypatch.setitem(mod._TRACE_STATE, task_key, state)

        ended = {}

        def fake_end_observation(obs, *, output=None, metadata=None, usage_details=None, cost_details=None, **_):
            ended["observation"] = obs
            ended["output"] = output
            ended["metadata"] = metadata

        monkeypatch.setattr(mod, "_end_observation", fake_end_observation)

        mod.on_post_tool_call(
            tool_name="web_extract",
            args={"urls": ["https://example.com"]},
            result='{"results": [{"url": "https://example.com", "content": "Example Domain"}]}',
            task_id="task-1",
            session_id="session-1",
            tool_call_id="call-1",
        )

        assert ended["observation"] is observation
        assert state.turn_tool_calls[0]["output"] == ended["output"]
        assert state.turn_tool_calls[0]["function"]["output"] == ended["output"]
        assert state.turn_tool_calls[0]["output"] == {
            "results": [{"url": "https://example.com", "content": "Example Domain"}]
        }

    def test_serialize_messages_keeps_tool_name_and_call_id(self):
        sys.modules.pop("langfuse_plugin", None)
        mod = importlib.import_module("langfuse_plugin")

        messages = [{
            "role": "tool",
            "name": "web_extract",
            "tool_call_id": "call-1",
            "content": '{"ok": true}',
        }]

        assert mod._serialize_messages(messages) == [{
            "role": "tool",
            "name": "web_extract",
            "tool_call_id": "call-1",
            "content": {"ok": True},
        }]


class TestToolObservationKeying:
    """Tests for pre/post tool_call observation matching when tool_call_id is absent."""

    def _make_mod(self):
        sys.modules.pop("langfuse_plugin", None)
        return importlib.import_module("langfuse_plugin")

    def test_empty_tool_call_id_single_tool_sets_output(self, monkeypatch):
        mod = self._make_mod()
        obs = object()
        state = mod.TraceState(trace_id="t", root_span=None)
        state.pending_tools_by_name.setdefault("my_tool", []).append(obs)

        task_key = mod._trace_key("task-1", "sess-1")
        monkeypatch.setitem(mod._TRACE_STATE, task_key, state)

        ended = {}

        def fake_end(o, *, output=None, metadata=None, **kw):
            ended["obs"] = o
            ended["output"] = output

        monkeypatch.setattr(mod, "_end_observation", fake_end)

        mod.on_post_tool_call(
            tool_name="my_tool",
            args={},
            result='{"ok": true}',
            task_id="task-1",
            session_id="sess-1",
            tool_call_id="",
        )

        assert ended["obs"] is obs
        assert ended["output"] == {"ok": True}
        assert state.pending_tools_by_name.get("my_tool") is None

    @pytest.mark.parametrize("status,level", [("error", "ERROR"), ("blocked", "WARNING"), ("ok", None)])
    def test_tool_status_sets_observation_level(self, monkeypatch, status, level):
        """#81731: core's post_tool_call status must surface as the Langfuse level,
        else a failed tool call is indistinguishable from a successful one."""
        mod = self._make_mod()
        state = mod.TraceState(trace_id="t", root_span=None)
        state.tools["call_1"] = object()
        monkeypatch.setitem(mod._TRACE_STATE, mod._trace_key("task-1", "sess-1"), state)
        ended = {}
        monkeypatch.setattr(mod, "_end_observation", lambda o, **kw: ended.update(kw))

        mod.on_post_tool_call(tool_name="read_file", args={}, result='{"error": "File not found"}',
                              task_id="task-1", session_id="sess-1", tool_call_id="call_1",
                              status=status, error_type="tool_error" if status == "error" else None)

        assert ended.get("level") == level
        assert bool(ended.get("status_message")) is bool(level)


    def test_threaded_post_calls_preserve_fifo_under_lock(self, monkeypatch):
        """The actual concurrency contract: when 8 threads race to drain
        the pending queue, no observation is consumed twice and none is
        lost.  Validates ``_STATE_LOCK`` discipline, not Python list
        semantics."""
        import threading

        mod = self._make_mod()
        n = 8
        observations = [object() for _ in range(n)]
        state = mod.TraceState(trace_id="t", root_span=None)
        state.pending_tools_by_name["web_extract"] = list(observations)

        task_key = mod._trace_key("task-thr", "sess-thr")
        monkeypatch.setitem(mod._TRACE_STATE, task_key, state)

        recorded: list = []
        lock = threading.Lock()

        def fake_end(o, *, output=None, metadata=None, **kw):
            with lock:
                recorded.append(o)

        monkeypatch.setattr(mod, "_end_observation", fake_end)

        barrier = threading.Barrier(n)

        def worker():
            barrier.wait()
            mod.on_post_tool_call(
                tool_name="web_extract", args={}, result='{"ok": true}',
                task_id="task-thr", session_id="sess-thr", tool_call_id="",
            )

        threads = [threading.Thread(target=worker) for _ in range(n)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        # Every observation was consumed exactly once; queue is empty.
        assert len(recorded) == n
        assert set(map(id, recorded)) == set(map(id, observations))
        assert state.pending_tools_by_name.get("web_extract") is None

    def test_explicit_tool_call_id_uses_tools_dict(self, monkeypatch):
        """When tool_call_id is present, pending_tools_by_name is not touched."""
        mod = self._make_mod()
        obs = object()
        state = mod.TraceState(trace_id="t", root_span=None)
        state.tools["call-99"] = obs

        task_key = mod._trace_key("task-1", "sess-1")
        monkeypatch.setitem(mod._TRACE_STATE, task_key, state)

        ended = {}

        def fake_end(o, *, output=None, metadata=None, **kw):
            ended["obs"] = o
            ended["output"] = output

        monkeypatch.setattr(mod, "_end_observation", fake_end)

        mod.on_post_tool_call(
            tool_name="my_tool", args={}, result='{"status": "done"}',
            task_id="task-1", session_id="sess-1", tool_call_id="call-99",
        )

        assert ended["obs"] is obs
        assert ended["output"] == {"status": "done"}
        assert not state.tools


class TestUsageFromSanitizedResponse:
    """Regression: ``post_api_request`` delivers ``response`` as a sanitized
    dict (no ``.usage`` attribute) plus a separate ``usage`` summary dict. The
    post-call handler must read the ``usage`` dict instead of treating the dict
    response as a usage-bearing object and dropping all token/cost data."""

    def _setup(self, mod, monkeypatch):
        # Active client so on_post_llm_call does not early-return.
        monkeypatch.setattr(mod, "_get_langfuse", lambda: object())
        observation = object()
        state = mod.TraceState(trace_id="trace-1", root_span=None)
        state.generations[mod._request_key(1)] = observation
        monkeypatch.setitem(mod._TRACE_STATE, mod._trace_key("task-1", "session-1"), state)
        captured = {}

        def fake_end_observation(obs, *, output=None, metadata=None, usage_details=None, cost_details=None, **_):
            captured["usage_details"] = usage_details

        monkeypatch.setattr(mod, "_end_observation", fake_end_observation)
        return captured

    def test_sanitized_dict_response_uses_usage_dict(self, monkeypatch):
        sys.modules.pop("langfuse_plugin", None)
        mod = importlib.import_module("langfuse_plugin")
        captured = self._setup(mod, monkeypatch)

        # A plain dict has no ``.usage`` attribute — mirrors post_api_request.
        mod.on_post_llm_call(
            task_id="task-1",
            session_id="session-1",
            api_call_count=1,
            model="gemini-3-flash-preview",
            response={"model": "gemini-3-flash-preview", "usage": {"input_tokens": 100, "output_tokens": 20}},
            usage={"input_tokens": 100, "output_tokens": 20},
            assistant_content_chars=42,
        )

        # Before the fix the dict response shadowed the usage dict and tokens
        # were lost (usage_details == {}).
        assert captured["usage_details"] == {"input": 100, "output": 20}

    def test_real_response_object_with_usage_still_used(self, monkeypatch):
        sys.modules.pop("langfuse_plugin", None)
        mod = importlib.import_module("langfuse_plugin")
        captured = self._setup(mod, monkeypatch)

        # A response object that genuinely carries usage must still take the
        # response-object path (post_llm_call / legacy behavior).
        seen = {}

        def fake_usage_and_cost(resp, **_):
            seen["resp"] = resp
            return {"input": 7, "output": 3}, {}

        monkeypatch.setattr(mod, "_usage_and_cost", fake_usage_and_cost)

        class _Resp:
            usage = {"prompt_tokens": 7, "completion_tokens": 3}

        resp = _Resp()
        mod.on_post_llm_call(
            task_id="task-1",
            session_id="session-1",
            api_call_count=1,
            model="gemini-3-flash-preview",
            response=resp,
            usage={"input_tokens": 999, "output_tokens": 999},
            assistant_content_chars=42,
        )

        assert seen["resp"] is resp
        assert captured["usage_details"] == {"input": 7, "output": 3}


# ---------------------------------------------------------------------------
# Model attribution: wire truth over stale agent attribute
# ---------------------------------------------------------------------------

class TestModelAttribution:
    def _fresh_plugin(self):
        sys.modules.pop("langfuse_plugin", None)
        return importlib.import_module("langfuse_plugin")

    def _client_capturing_generations(self, gens):
        class _Gen:
            def update(self, **kw): pass
            def end(self, **kw): pass

        class _Span:
            def update(self, **kw): pass
            def end(self, **kw): pass
            def set_trace_io(self, **kw): pass
            def start_observation(self, **kw):
                gens.append(kw)
                return _Gen()

        class _RootCM:
            def __enter__(self): return _Span()
            def __exit__(self, *exc): return False

        class _Client:
            def create_trace_id(self, seed=None): return "t"
            def start_as_current_observation(self, **kw): return _RootCM()
            def start_observation(self, **kw): return _RootCM().__enter__()
            def flush(self): pass

        return _Client()

    def test_pre_api_request_prefers_request_body_model(self, monkeypatch):
        """Agent attribute says old model; request body says the switched one."""
        mod = self._fresh_plugin()
        gens: list = []
        monkeypatch.setattr(mod, "_get_langfuse", lambda: self._client_capturing_generations(gens))
        mod._TRACE_STATE.clear()

        mod.on_pre_llm_request(
            task_id="t", session_id="s", turn_id="s:t:turn1",
            api_call_count=1,
            model="old-model-attr",
            provider="openrouter",
            request_messages=[{"role": "user", "content": "hi"}],
            request={"body": {"model": "switched/new-model"}},
        )
        assert gens, "no generation started"
        assert gens[0]["model"] == "switched/new-model"

    def test_pre_api_request_falls_back_to_attr_without_body_model(self, monkeypatch):
        mod = self._fresh_plugin()
        gens: list = []
        monkeypatch.setattr(mod, "_get_langfuse", lambda: self._client_capturing_generations(gens))
        mod._TRACE_STATE.clear()

        mod.on_pre_llm_request(
            task_id="t", session_id="s", turn_id="s:t:turn2",
            api_call_count=1,
            model="attr-model",
            request_messages=[{"role": "user", "content": "hi"}],
            request={"body": {}},
        )
        assert gens[0]["model"] == "attr-model"

    def _post_with(self, mod, monkeypatch, *, start_model=None, usage_and_cost=None, **kw):
        monkeypatch.setattr(mod, "_get_langfuse", lambda: object())
        monkeypatch.setattr(mod, "_usage_and_cost",
                            usage_and_cost or (lambda *a, **k: ({"input": 1, "output": 1}, {})))
        mod._TRACE_STATE.clear()

        class _Gen:
            def __init__(self): self.updates = []
            def update(self, **u): self.updates.append(u)
            def end(self, **u): pass

        class _Root:
            def update(self, **u): pass
            def end(self, **u): pass
            def set_trace_io(self, **u): pass

        turn_id = "s:t:turn4"
        key = mod._trace_key("t", "s", turn_id=turn_id)
        state = mod.TraceState(trace_id="x", root_span=_Root())
        gen = state.generations["1"] = _Gen()
        if start_model:
            state.generation_models["1"] = start_model
        mod._TRACE_STATE[key] = state

        class _Resp:
            usage = {"prompt_tokens": 1, "completion_tokens": 1}

        mod.on_post_llm_call(task_id="t", session_id="s", turn_id=turn_id, api_call_count=1,
                             response=_Resp(), assistant_content_chars=2, **kw)
        return gen.updates

    def test_post_api_request_uses_response_model_for_cost(self, monkeypatch):
        """Cost estimation must key off the model that actually served."""
        mod = self._fresh_plugin()
        seen = {}
        def fake_usage_and_cost(response, *, provider, api_mode, model, base_url):
            seen["model"] = model
            return {"input": 1, "output": 1}, {}
        self._post_with(mod, monkeypatch, usage_and_cost=fake_usage_and_cost,
                        model="stale-attr-model", response_model="actual/served-model")
        assert seen["model"] == "actual/served-model"

    def test_post_api_request_records_served_model_on_generation(self, monkeypatch):
        """The generation starts with the requested model; the served one must replace it."""
        mod = self._fresh_plugin()
        (u,) = self._post_with(mod, monkeypatch, model="requested/alias",
                               response_model="actual/served-model")
        assert u["model"] == "actual/served-model"
        assert u["metadata"]["requested_model"] == "requested/alias"

    def test_post_api_request_without_response_model_keeps_requested(self, monkeypatch):
        mod = self._fresh_plugin()
        (u,) = self._post_with(mod, monkeypatch, model="requested/alias", response_model=None)
        assert "model" not in u
        assert "requested_model" not in u["metadata"]

    def test_post_api_request_same_model_adds_no_requested_meta(self, monkeypatch):
        mod = self._fresh_plugin()
        (u,) = self._post_with(mod, monkeypatch, model="m", response_model="m")
        assert u["model"] == "m"
        assert "requested_model" not in u["metadata"]

    def test_served_as_dispatched_is_not_flagged_when_hook_model_differs(self, monkeypatch):
        """Body model and response agree; only agent.model (the hook model) differs."""
        mod = self._fresh_plugin()
        (u,) = self._post_with(mod, monkeypatch, start_model="fallback/model",
                               model="agent/model", response_model="fallback/model")
        assert u["model"] == "fallback/model"
        assert "requested_model" not in u["metadata"]

    def test_reroute_is_reported_against_the_dispatched_model(self, monkeypatch):
        mod = self._fresh_plugin()
        (u,) = self._post_with(mod, monkeypatch, start_model="fallback/model",
                               model="agent/model", response_model="served/other")
        assert u["model"] == "served/other"
        assert u["metadata"]["requested_model"] == "fallback/model"

    def test_pre_then_post_uses_the_request_body_model_end_to_end(self, monkeypatch):
        """Through both hooks: pre records the body model, post compares against it."""
        mod = self._fresh_plugin()
        updates: list = []

        class _Gen:
            def update(self, **u): updates.append(u)
            def end(self, **u): pass

        class _Span:
            def update(self, **kw): pass
            def end(self, **kw): pass
            def set_trace_io(self, **kw): pass
            def start_observation(self, **kw): return _Gen()

        class _RootCM:
            def __enter__(self): return _Span()
            def __exit__(self, *exc): return False

        class _Client:
            def create_trace_id(self, seed=None): return "t"
            def start_as_current_observation(self, **kw): return _RootCM()
            def start_observation(self, **kw): return _RootCM().__enter__()
            def flush(self): pass

        client = _Client()
        monkeypatch.setattr(mod, "_get_langfuse", lambda: client)
        monkeypatch.setattr(mod, "_usage_and_cost", lambda *a, **k: ({"input": 1, "output": 1}, {}))
        mod._TRACE_STATE.clear()
        turn_id = "s:t:turn5"
        mod.on_pre_llm_request(task_id="t", session_id="s", turn_id=turn_id, api_call_count=1,
                               model="agent/model", request_messages=[{"role": "user", "content": "hi"}],
                               request={"body": {"model": "fallback/model"}})

        class _Resp:
            usage = {"prompt_tokens": 1, "completion_tokens": 1}

        mod.on_post_llm_call(task_id="t", session_id="s", turn_id=turn_id, api_call_count=1,
                             model="agent/model", response_model="fallback/model",
                             response=_Resp(), assistant_content_chars=2)
        (u,) = [x for x in updates if "metadata" in x]
        assert u["model"] == "fallback/model"
        assert "requested_model" not in u["metadata"]
        state = mod._TRACE_STATE.get(mod._trace_key("t", "s", turn_id=turn_id))
        assert state is None or not state.generation_models


# ---------------------------------------------------------------------------
# Cost total: explicit "total" alongside the per-type breakdown
# ---------------------------------------------------------------------------

class TestCostTotal:
    """Langfuse ingests per-type ``cost_details`` keys but does not derive
    ``calculatedTotalCost`` from them. Without an explicit ``total`` the
    dashboard reads 0 for every priced generation."""

    def _fresh_plugin(self):
        sys.modules.pop("langfuse_plugin", None)
        return importlib.import_module("langfuse_plugin")

    def test_response_path_totals_the_breakdown(self):
        mod = self._fresh_plugin()

        class _Usage:
            input_tokens = 1000
            output_tokens = 500
            cache_read_input_tokens = 2000
            cache_creation_input_tokens = 0

        class _Resp:
            usage = _Usage()

        _, cost_details = mod._usage_and_cost(
            _Resp(),
            provider="anthropic",
            api_mode="anthropic_messages",
            model="claude-sonnet-4-6",
            base_url="",
        )

        components = {k: v for k, v in cost_details.items() if k != "total"}
        assert components
        assert cost_details["total"] == pytest.approx(sum(components.values()))

    def test_usage_summary_path_totals_the_breakdown(self, monkeypatch):
        mod = self._fresh_plugin()
        monkeypatch.setattr(mod, "_get_langfuse", lambda: object())
        state = mod.TraceState(trace_id="trace-1", root_span=None)
        state.generations[mod._request_key(1)] = object()
        monkeypatch.setitem(mod._TRACE_STATE, mod._trace_key("task-1", "session-1"), state)
        captured = {}

        def fake_end_observation(obs, *, output=None, metadata=None, usage_details=None, cost_details=None, **_):
            captured["cost_details"] = cost_details

        monkeypatch.setattr(mod, "_end_observation", fake_end_observation)

        # A dict response has no ``.usage``, so the handler takes the
        # usage-summary path rather than the response-object path.
        mod.on_post_llm_call(
            task_id="task-1",
            session_id="session-1",
            api_call_count=1,
            model="claude-sonnet-4-6",
            provider="anthropic",
            response={"model": "claude-sonnet-4-6"},
            usage={"input_tokens": 1000, "output_tokens": 500},
            assistant_content_chars=42,
        )

        cost_details = captured["cost_details"]
        components = {k: v for k, v in cost_details.items() if k != "total"}
        assert components
        assert cost_details["total"] == pytest.approx(sum(components.values()))

    def test_context_tier_breakdown_sums_to_total(self):
        # gemini-2.5-pro bills the whole request at its *_above rates past 200k prompt
        # tokens; the breakdown used the base rates (total 0.89 vs parts 0.4475).
        from agent.usage_pricing import CanonicalUsage

        mod = self._fresh_plugin()
        usage = CanonicalUsage(input_tokens=350_000, output_tokens=1_000)
        _, cost_details = mod._canonical_usage_and_cost(usage, provider="gemini", model="gemini-2.5-pro", base_url="")
        components = {k: v for k, v in cost_details.items() if k != "total"}
        assert components and cost_details["total"] == pytest.approx(sum(components.values()))

    def test_priced_model_with_no_tokens_reports_no_total(self):
        mod = self._fresh_plugin()

        class _Usage:
            input_tokens = 0
            output_tokens = 0

        class _Resp:
            usage = _Usage()

        _, cost_details = mod._usage_and_cost(
            _Resp(),
            provider="anthropic",
            api_mode="anthropic_messages",
            model="claude-sonnet-4-6",
            base_url="",
        )

        # A priced model that billed nothing writes no per-type keys, so
        # summing them must not invent a 0.0 total on an empty breakdown.
        assert cost_details == {}


# ---------------------------------------------------------------------------
# Capture modes: metadata | sanitized | full  (HERMES_LANGFUSE_CAPTURE)
# ---------------------------------------------------------------------------

class TestCaptureModes:
    def _fresh_plugin(self):
        sys.modules.pop("langfuse_plugin", None)
        return importlib.import_module("langfuse_plugin")

    def test_default_mode_is_sanitized(self, monkeypatch):
        mod = self._fresh_plugin()
        monkeypatch.delenv("HERMES_LANGFUSE_CAPTURE", raising=False)
        assert mod._capture_mode() == "sanitized"

    def test_invalid_mode_falls_back_and_warns_once(self, monkeypatch, caplog):
        mod = self._fresh_plugin()
        monkeypatch.setenv("HERMES_LANGFUSE_CAPTURE", "everything")
        with caplog.at_level(logging.WARNING):
            assert mod._capture_mode() == "sanitized"
            assert mod._capture_mode() == "sanitized"
        warnings = [r for r in caplog.records if "HERMES_LANGFUSE_CAPTURE" in r.getMessage()]
        assert len(warnings) == 1

    def test_metadata_mode_omits_content(self, monkeypatch):
        mod = self._fresh_plugin()
        monkeypatch.setenv("HERMES_LANGFUSE_CAPTURE", "metadata")
        out = mod._capture_content("top secret prompt text")
        assert out == {"omitted": True, "type": "text", "chars": 22}
        obj = mod._capture_content({"password": "***", "path": "/x"})
        assert obj["omitted"] is True
        assert set(obj["keys"]) == {"password", "path"}
        assert "hunter22" not in str(obj)

    def test_metadata_mode_message_serialization_keeps_roles(self, monkeypatch):
        mod = self._fresh_plugin()
        monkeypatch.setenv("HERMES_LANGFUSE_CAPTURE", "metadata")
        msgs = mod._serialize_messages([
            {"role": "user", "content": "my ssn is 123-45-6789"},
            {"role": "assistant", "content": "noted"},
        ])
        assert [m["role"] for m in msgs] == ["user", "assistant"]
        assert all(isinstance(m["content"], dict) and m["content"]["omitted"] for m in msgs)
        assert "6789" not in str(msgs)

    def test_sanitized_mode_redacts_secrets(self, monkeypatch):
        mod = self._fresh_plugin()
        monkeypatch.setenv("HERMES_LANGFUSE_CAPTURE", "sanitized")
        samples = {
            "openai": "here sk-" + "a" * 20 + " done",
            "anthropic": "key sk-ant-" + "a" * 20 + " x",
            "github": "tok ghp_" + "a" * 36,
            "aws": "AKIA" + "A" * 16,
            "langfuse": "pk-lf-" + "a" * 20,
            "bearer": "Author...rer " + "a" * 20,
            "assignment": 'api_key="supersecretvalue"',
        }
        for name, text in samples.items():
            out = mod._capture_content(text)
            # redact_sensitive_text masks secrets (e.g. "sk-aaa...aaaa") or
            # replaces them with "«redacted:...»" sentinels — check that the
            # original secret substring is gone, not for a specific marker.
            assert text != out, f"{name} not redacted: {out!r}"

    def test_sanitized_mode_redacts_before_truncation(self, monkeypatch):
        mod = self._fresh_plugin()
        monkeypatch.setenv("HERMES_LANGFUSE_CAPTURE", "sanitized")
        secret = "sk-" + "z" * 40
        text = "x" * 100 + " " + secret + " " + "y" * 100
        out = mod._truncate_text(text, 120)
        assert "z" * 10 not in out
        assert text != out, "secret was not redacted before truncation"

    def test_sanitized_mode_keeps_ordinary_text(self, monkeypatch):
        mod = self._fresh_plugin()
        monkeypatch.setenv("HERMES_LANGFUSE_CAPTURE", "sanitized")
        text = "refactor the memory manager to emit spans"
        assert mod._capture_content(text) == text

    def test_full_mode_keeps_secret_shaped_text(self, monkeypatch):
        mod = self._fresh_plugin()
        monkeypatch.setenv("HERMES_LANGFUSE_CAPTURE", "full")
        text = "here sk-abc...1234 done"
        assert mod._capture_content(text) == text

    def test_sanitized_mode_masks_secret_fields_in_parsed_json(self, monkeypatch):
        # Tool results are JSON-parsed before redaction, which strips the key
        # context: an opaque token under "access_token" used to export raw.
        mod = self._fresh_plugin()
        token = "opaqTok-" + "7Qm2Xv9LkP4zR8wN1bY6"  # opaque: no vendor prefix for the text redactor
        inner = {"access_token": token, "username": "alice", "nested": [{"password": "***"}], "total_tokens": "70"}
        result = json.dumps({"output": json.dumps(inner), "exit_code": 0})
        monkeypatch.setenv("HERMES_LANGFUSE_CAPTURE", "sanitized")
        out = mod._capture_content(result, tool_result_of=("terminal", {}))["output"]
        assert out == {"access_token": "***", "username": "alice", "nested": [{"password": "***"}],
                       "total_tokens": "70"}
        monkeypatch.setenv("HERMES_LANGFUSE_CAPTURE", "full")
        assert mod._capture_content(result, tool_result_of=("terminal", {}))["output"] == inner

    def test_sanitized_mode_masks_bare_bearer_token(self, monkeypatch):
        mod = self._fresh_plugin()
        monkeypatch.setenv("HERMES_LANGFUSE_CAPTURE", "sanitized")
        out = mod._capture_content("call it with Bearer 9f8e7d6c5b4a39281706f5e4d3c2b1a0ffee please")
        assert "9f8e7d6c5b4a" not in out

    @staticmethod
    def _exported_tool_output(mod, monkeypatch, result):
        """Drive on_post_tool_call and return what the tool observation would export."""
        state = mod.TraceState(trace_id="trace-1", root_span=None)
        state.tools["call-1"] = object()
        monkeypatch.setitem(mod._TRACE_STATE, mod._trace_key("task-1", "session-1"), state)
        ended = {}
        monkeypatch.setattr(mod, "_end_observation", lambda obs, *, output=None, **_: ended.update(output=output))
        mod.on_post_tool_call(tool_name="terminal", args={"command": "x"}, result=result,
                              task_id="task-1", session_id="session-1", tool_call_id="call-1")
        return ended["output"]

    def test_sanitized_mode_masks_url_credentials_in_content(self, monkeypatch):
        """Core's default leaves user:pass@ and ?api_key= in URLs alone (OAuth callbacks must
        survive tool flows); a telemetry upload has no such need (hermes-agent#88608)."""
        mod = self._fresh_plugin()
        monkeypatch.setenv("HERMES_LANGFUSE_CAPTURE", "sanitized")
        text = "cloning https://bob:hunter2pass@git.internal/x.git via https://api.example/v1?api_key=opaq7Qm2Xv9LkP4zR8wN&q=1"
        out = self._exported_tool_output(mod, monkeypatch, json.dumps({"output": text, "exit_code": 0}))["output"]
        assert "hunter2pass" not in out and "opaq7Qm2Xv9LkP4zR8wN" not in out and "bob:" not in out, out
        assert "git.internal/x.git" in out and "q=1" in out
        monkeypatch.setenv("HERMES_LANGFUSE_CAPTURE", "full")
        assert self._exported_tool_output(mod, monkeypatch, json.dumps({"output": text}))["output"] == text

    def test_sanitized_mode_masks_numeric_secret_fields(self, monkeypatch):
        """JSON parsing turns a numeric password into an int, which the str-only key mask skipped."""
        mod = self._fresh_plugin()
        monkeypatch.setenv("HERMES_LANGFUSE_CAPTURE", "sanitized")
        inner = {"password": 123456, "api_key": 9.5, "token": True, "secret": None, "total_tokens": 70, "port": 5432}
        out = self._exported_tool_output(mod, monkeypatch, json.dumps({"output": json.dumps(inner)}))["output"]
        assert out == {"password": "***", "api_key": "***", "token": True, "secret": None,
                       "total_tokens": 70, "port": 5432}


# ---------------------------------------------------------------------------
# api_request_error hook
# ---------------------------------------------------------------------------

class TestApiRequestErrorHook:
    def _fresh_plugin(self):
        sys.modules.pop("langfuse_plugin", None)
        return importlib.import_module("langfuse_plugin")

    def _seed_state(self, mod, task_key, gen_key="1"):
        class _Gen:
            def __init__(self):
                self.updates = []
                self.ended = False
            def update(self, **kw):
                self.updates.append(kw)
            def end(self, **kw):
                self.ended = True

        class _Root:
            def __init__(self):
                self.ended = False
            def update(self, **kw): pass
            def end(self, **kw): self.ended = True
            def set_trace_io(self, **kw): pass

        gen = _Gen()
        root = _Root()
        state = mod.TraceState(trace_id="t", root_span=root)
        state.generations[gen_key] = gen
        mod._TRACE_STATE[task_key] = state
        return gen, root

    def test_retryable_error_closes_generation_keeps_turn(self, monkeypatch):
        mod = self._fresh_plugin()
        monkeypatch.setattr(mod, "_get_langfuse", lambda: object())
        mod._TRACE_STATE.clear()
        turn_id = "s:t:turn1"
        task_key = mod._trace_key("t", "s", turn_id=turn_id)
        gen, root = self._seed_state(mod, task_key)

        mod.on_api_request_error(
            task_id="t", session_id="s", api_call_count=1,
            turn_id=turn_id,
            status_code=429, retryable=True, retry_count=1, max_retries=3,
            error={"type": "RateLimitError", "message": "slow down"},
        )

        assert gen.ended is True
        assert any(u.get("level") == "ERROR" for u in gen.updates)
        # error metadata landed
        meta = [u["metadata"] for u in gen.updates if "metadata" in u]
        assert meta and meta[0]["status_code"] == 429
        # turn stays open for the retry
        assert task_key in mod._TRACE_STATE
        assert root.ended is False

    def test_terminal_error_finishes_turn(self, monkeypatch):
        mod = self._fresh_plugin()
        monkeypatch.setattr(mod, "_get_langfuse", lambda: type("C", (), {"flush": lambda self: None})())
        mod._TRACE_STATE.clear()
        turn_id = "s:t:turn2"
        task_key = mod._trace_key("t", "s", turn_id=turn_id)
        gen, root = self._seed_state(mod, task_key)

        mod.on_api_request_error(
            task_id="t", session_id="s", api_call_count=1,
            turn_id=turn_id,
            status_code=401, retryable=False,
            error={"type": "AuthenticationError", "message": "bad key"},
        )

        assert gen.ended is True
        assert task_key not in mod._TRACE_STATE
        assert root.ended is True

    def test_error_hook_noops_without_state(self, monkeypatch):
        mod = self._fresh_plugin()
        monkeypatch.setattr(mod, "_get_langfuse", lambda: object())
        mod._TRACE_STATE.clear()
        # Must not raise
        mod.on_api_request_error(
            task_id="t", session_id="s", api_call_count=1,
            error={"type": "X", "message": "y"}, retryable=False,
        )

    def test_error_message_respects_capture_mode(self, monkeypatch):
        mod = self._fresh_plugin()
        monkeypatch.setenv("HERMES_LANGFUSE_CAPTURE", "metadata")
        monkeypatch.setattr(mod, "_get_langfuse", lambda: object())
        mod._TRACE_STATE.clear()
        turn_id = "s:t:turn3"
        task_key = mod._trace_key("t", "s", turn_id=turn_id)
        gen, _root = self._seed_state(mod, task_key)

        mod.on_api_request_error(
            task_id="t", session_id="s", api_call_count=1, turn_id=turn_id,
            retryable=True,
            error={"type": "APIError", "message": "secret prompt echo sk-abc"},
        )
        meta = next(u["metadata"] for u in gen.updates if "metadata" in u)
        assert isinstance(meta["error_message"], dict)
        assert meta["error_message"]["omitted"] is True

    def test_unanswered_calls_close_as_error_at_turn_end(self, monkeypatch):
        """#81731: a generation/tool that never got its post hook used to close
        at level DEFAULT, indistinguishable from a successful call."""
        mod = self._fresh_plugin()
        client = type("_Client", (), {"flush": lambda self: None})()
        monkeypatch.setattr(mod, "_LANGFUSE_CLIENT", client)
        monkeypatch.setattr(mod, "_get_langfuse", lambda: client)
        mod._TRACE_STATE.clear()
        task_key = mod._trace_key("s", "s", turn_id="s:turn4")  # gateway shape: task_id == session_id
        gen, root = self._seed_state(mod, task_key)
        tool, _ = self._seed_state(mod, "unused")
        mod._TRACE_STATE[task_key].tools["call_1"] = tool

        # An interrupted turn never reaches post_llm_call; the session boundary closes it.
        mod.on_session_finalize(session_id="s", reason="session_boundary")

        assert root.ended and task_key not in mod._TRACE_STATE
        for obs in (gen, tool):
            assert obs.ended and any(u.get("level") == "ERROR" and u.get("status_message") for u in obs.updates)

    def test_superseded_attempt_closes_as_warning(self, monkeypatch):
        """#81731: a retry's pre_api_request supersedes an attempt that got no
        response; that attempt is marked WARNING, not closed silently."""
        mod = self._fresh_plugin()
        monkeypatch.setattr(mod, "_get_langfuse", lambda: object())
        monkeypatch.setattr(mod, "_start_child_observation", lambda *a, **k: object())
        mod._TRACE_STATE.clear()
        task_key = mod._trace_key("t", "s", turn_id="s:t:turn5")
        gen, _root = self._seed_state(mod, task_key)

        mod.on_pre_llm_request(task_id="t", session_id="s", turn_id="s:t:turn5", api_call_count=1)

        assert gen.ended and any(u.get("level") == "WARNING" for u in gen.updates)


# ---------------------------------------------------------------------------
# on_session_finalize hook
# ---------------------------------------------------------------------------

class TestSessionFinalizeHook:
    def _fresh_plugin(self):
        sys.modules.pop("langfuse_plugin", None)
        return importlib.import_module("langfuse_plugin")

    def _client(self, flushes):
        class _Client:
            def flush(self):
                flushes.append(1)
        return _Client()

    def _state(self, mod):
        class _Root:
            def __init__(self):
                self.ended = False
            def update(self, **kw): pass
            def end(self, **kw): self.ended = True
            def set_trace_io(self, **kw): pass
        root = _Root()
        return mod.TraceState(trace_id="t", root_span=root), root

    def test_finalize_closes_matching_session_traces(self, monkeypatch):
        mod = self._fresh_plugin()
        flushes = []
        client = self._client(flushes)
        monkeypatch.setattr(mod, "_LANGFUSE_CLIENT", client)
        monkeypatch.setattr(mod, "_get_langfuse", lambda: client)
        mod._TRACE_STATE.clear()

        s1, r1 = self._state(mod)
        s2, r2 = self._state(mod)
        mod._TRACE_STATE["session:sess-a:turn:1"] = s1
        mod._TRACE_STATE["session:sess-b:turn:1"] = s2

        mod.on_session_finalize(session_id="sess-a")

        assert "session:sess-a:turn:1" not in mod._TRACE_STATE
        assert "session:sess-b:turn:1" in mod._TRACE_STATE
        assert r1.ended is True
        assert r2.ended is False
        assert not flushes  # session rotation must not wait for network export

    def test_finalize_without_session_closes_all(self, monkeypatch):
        mod = self._fresh_plugin()
        flushes = []
        client = self._client(flushes)
        monkeypatch.setattr(mod, "_LANGFUSE_CLIENT", client)
        monkeypatch.setattr(mod, "_get_langfuse", lambda: client)
        mod._TRACE_STATE.clear()

        s1, r1 = self._state(mod)
        mod._TRACE_STATE["session:sess-x:turn:1"] = s1
        mod.on_session_finalize()
        assert not mod._TRACE_STATE
        assert r1.ended is True

    def test_finalize_noop_when_client_never_initialized(self):
        mod = self._fresh_plugin()
        mod._TRACE_STATE.clear()
        # _LANGFUSE_CLIENT is None on a fresh module; must not raise or init.
        mod.on_session_finalize(session_id="whatever")

    def test_finalize_shuts_down_client_on_process_exit(self, monkeypatch):
        """reason="shutdown" must call client.shutdown() while the interpreter
        is alive, so the SDK's own atexit handler (which runs during
        interpreter finalization, after opentelemetry.trace.Span is torn
        down) becomes a no-op instead of raising the "isinstance() arg 2
        must be a type" TypeError on quit."""
        mod = self._fresh_plugin()
        events = []

        class _Client:
            def flush(self):
                events.append("flush")

            def shutdown(self):
                events.append("shutdown")

        client = _Client()
        monkeypatch.setattr(mod, "_LANGFUSE_CLIENT", client)
        monkeypatch.setattr(mod, "_get_langfuse", lambda: client)
        mod._TRACE_STATE.clear()

        mod.on_session_finalize(session_id="sess-a", reason="shutdown")
        assert "shutdown" in events
        assert events.index("flush") < events.index("shutdown")

    def test_finalize_keeps_client_alive_on_session_rotation(self, monkeypatch):
        """/new, /reset, and gateway session expiry finalize the session but
        the process lives on — the cached client must NOT be shut down or
        later sessions silently stop exporting."""
        mod = self._fresh_plugin()
        events = []

        class _Client:
            def flush(self):
                events.append("flush")

            def shutdown(self):
                events.append("shutdown")

        client = _Client()
        monkeypatch.setattr(mod, "_LANGFUSE_CLIENT", client)
        monkeypatch.setattr(mod, "_get_langfuse", lambda: client)
        mod._TRACE_STATE.clear()

        for reason in ("session_boundary", "new_session", "session_expired", ""):
            mod.on_session_finalize(session_id="sess-a", reason=reason)
        assert "shutdown" not in events
        assert "flush" not in events

    @pytest.mark.parametrize("boundary", ["success", "error", "session"])
    def test_live_boundary_returns_while_flush_is_blocked(self, monkeypatch, boundary):
        """#87468: client.flush() waits on the network; a hung backend must not
        hold up a finished turn (cron watchdog then discards the real output).
        Live boundaries end spans and return; the SDK exporter delivers."""
        import threading
        from concurrent.futures import ThreadPoolExecutor

        mod = self._fresh_plugin()
        release = threading.Event()

        class _Obs:
            def update(self, **kw): pass
            def end(self, **kw): pass

        class _Client:
            def flush(self):
                release.wait(10)

        client = _Client()
        monkeypatch.setattr(mod, "_LANGFUSE_CLIENT", client)
        monkeypatch.setattr(mod, "_get_langfuse", lambda: client)
        mod._TRACE_STATE.clear()
        key = mod._trace_key("", "live", turn_id="turn")
        mod._TRACE_STATE[key] = mod.TraceState(trace_id="t", root_span=_Obs(),
                                               generations={"1": _Obs()})
        finish = {
            "success": lambda: mod.on_post_llm_call(session_id="live", turn_id="turn", api_call_count=1,
                                                    assistant_response="done"),
            "error": lambda: mod.on_api_request_error(session_id="live", turn_id="turn", api_call_count=1,
                                                      retryable=False, error={"type": "APIError"}),
            "session": lambda: mod.on_session_finalize(session_id="live", reason="session_boundary"),
        }[boundary]
        with ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(finish)
            try:
                future.result(timeout=2)
                assert key not in mod._TRACE_STATE
            finally:
                release.set()


# ---------------------------------------------------------------------------
# Subagent tracing: delegated children as spans under the parent turn
# ---------------------------------------------------------------------------

class TestSubagentTracing:
    """``tools/delegate_tool.py`` emits subagent_start/subagent_stop. The
    payloads carry ``parent_turn_id`` but no ``task_id``, so the parent trace
    must be resolved by turn id rather than by rebuilding the scope key."""

    def _fresh_plugin(self):
        sys.modules.pop("langfuse_plugin", None)
        return importlib.import_module("langfuse_plugin")

    def _state(self, mod, monkeypatch, key, spans):
        class _Obs:
            def __init__(self, kw):
                self.kw = kw
                self.ended = False
                self.updates = {}

            def update(self, **kw):
                self.updates.update(kw)

            def end(self, **kw):
                self.ended = True

        class _Root:
            def start_observation(self, **kw):
                obs = _Obs(kw)
                spans.append(obs)
                return obs

        monkeypatch.setattr(mod, "_get_langfuse", lambda: object())
        state = mod.TraceState(trace_id="trace-1", root_span=_Root())
        monkeypatch.setitem(mod._TRACE_STATE, key, state)
        return state

    def test_start_attaches_span_despite_task_scoped_key(self, monkeypatch):
        mod = self._fresh_plugin()
        spans = []
        # Key minted by the LLM hooks with a task id — a naive rebuild from
        # session_id alone would not match this.
        state = self._state(mod, monkeypatch, "task:task-9:turn:turn-7", spans)

        mod.on_subagent_start(
            parent_session_id="sess-1",
            parent_turn_id="turn-7",
            child_session_id="child-sess-1",
            child_subagent_id="sub-1",
            child_role="researcher",
            child_goal="find the thing",
        )

        assert len(spans) == 1
        assert spans[0].kw["name"] == "Subagent: researcher"
        assert spans[0].kw["metadata"]["child_subagent_id"] == "sub-1"
        assert "child-sess-1" in state.subagents

    def test_stop_ends_span_and_records_outcome(self, monkeypatch):
        mod = self._fresh_plugin()
        spans = []
        state = self._state(mod, monkeypatch, "task:task-9:turn:turn-7", spans)

        mod.on_subagent_start(
            parent_session_id="sess-1", parent_turn_id="turn-7",
            child_session_id="child-sess-1", child_role="researcher",
            child_goal="find the thing",
        )
        mod.on_subagent_stop(
            parent_session_id="sess-1", parent_turn_id="turn-7",
            child_session_id="child-sess-1", child_role="researcher",
            child_summary="found it", child_status="ok",
            tool_call_history=[{"name": "read_file"}, {"name": "grep"}],
            duration_ms=1234,
        )

        assert spans[0].ended is True
        assert spans[0].updates["metadata"]["status"] == "ok"
        assert spans[0].updates["metadata"]["tool_call_count"] == 2
        assert spans[0].updates["metadata"]["duration_ms"] == 1234
        # Popped so a repeated stop cannot double-end the span.
        assert not state.subagents

    def test_unknown_turn_is_a_noop(self, monkeypatch):
        mod = self._fresh_plugin()
        spans = []
        self._state(mod, monkeypatch, "task:task-9:turn:turn-7", spans)

        mod.on_subagent_start(
            parent_turn_id="turn-does-not-exist",
            child_session_id="child-sess-1", child_role="researcher",
        )
        mod.on_subagent_stop(
            parent_turn_id="turn-does-not-exist",
            child_session_id="child-sess-1",
        )

        assert spans == []

    def test_start_without_child_session_is_a_noop(self, monkeypatch):
        mod = self._fresh_plugin()
        spans = []
        self._state(mod, monkeypatch, "task:task-9:turn:turn-7", spans)

        # subagent_stop keys on child_session_id, so a start without one could
        # never be matched and must not open an unclosable span.
        mod.on_subagent_start(
            parent_turn_id="turn-7", child_session_id=None, child_role="researcher",
        )

        assert spans == []


# ---------------------------------------------------------------------------
# MoA fan-out: one generation per advisor, priced at the advisor's own model
# ---------------------------------------------------------------------------

class TestMoAReferenceGenerations:
    """MoA returns only the aggregator's response, so without per-advisor
    generations the whole fan-out collapses into one line priced at the
    aggregator's model. Advisors routinely run on a different provider."""

    def _fresh_plugin(self):
        sys.modules.pop("langfuse_plugin", None)
        return importlib.import_module("langfuse_plugin")

    def _state(self, mod, monkeypatch, gens):
        class _Obs:
            def __init__(self, kw):
                self.kw = kw
                self.updates = {}
                self.ended = False

            def update(self, **kw):
                self.updates.update(kw)

            def end(self, **kw):
                self.ended = True

        class _Root:
            def start_observation(self, **kw):
                obs = _Obs(kw)
                gens.append(obs)
                return obs

        monkeypatch.setattr(mod, "_get_langfuse", lambda: object())
        return mod.TraceState(trace_id="t", root_span=_Root())

    def _refs(self):
        return [
            {
                "label": "anthropic:claude-sonnet-4-6",
                "model": "claude-sonnet-4-6",
                "provider": "anthropic",
                "usage": {"input_tokens": 100, "output_tokens": 50},
                "cost_usd": 0.001,
                "cost_status": "ok",
                "cost_source": "pricing_table",
            },
            {
                "label": "openai:gpt-5",
                "model": "gpt-5",
                "provider": "openai",
                "usage": {"input_tokens": 80, "output_tokens": 40, "reasoning_tokens": 10},
                "cost_usd": 0.002,
            },
        ]

    def test_one_generation_per_advisor_with_own_model_and_cost(self, monkeypatch):
        mod = self._fresh_plugin()
        gens = []
        state = self._state(mod, monkeypatch, gens)

        mod._emit_moa_reference_generations(state, client=object(), references=self._refs())

        assert len(gens) == 2
        assert gens[0].kw["model"] == "claude-sonnet-4-6"
        assert gens[1].kw["model"] == "gpt-5"
        # Each advisor's dollars, not the aggregator's rate applied to all.
        assert gens[0].updates["cost_details"]["total"] == pytest.approx(0.001)
        assert gens[1].updates["cost_details"]["total"] == pytest.approx(0.002)
        assert gens[0].updates["usage_details"] == {"input": 100, "output": 50}
        # Reasoning is a subset of output, split out so the buckets still sum to 120.
        assert gens[1].updates["usage_details"] == {"input": 80, "output": 30, "output_reasoning_tokens": 10}
        assert all(g.ended for g in gens)

    def test_repeat_emit_is_deduped_within_a_turn(self, monkeypatch):
        mod = self._fresh_plugin()
        gens = []
        state = self._state(mod, monkeypatch, gens)

        # The MoA client holds its last fan-out until the next one, so a
        # tool-loop turn delivers the same references on every API call.
        refs = self._refs()
        mod._emit_moa_reference_generations(state, client=object(), references=refs)
        mod._emit_moa_reference_generations(state, client=object(), references=refs)
        mod._emit_moa_reference_generations(state, client=object(), references=list(refs))

        assert len(gens) == 2

    def test_a_new_fanout_emits_again(self, monkeypatch):
        mod = self._fresh_plugin()
        gens = []
        state = self._state(mod, monkeypatch, gens)

        mod._emit_moa_reference_generations(state, client=object(), references=self._refs())
        second = self._refs()
        second[0]["usage"]["output_tokens"] = 999
        mod._emit_moa_reference_generations(state, client=object(), references=second)

        assert len(gens) == 4

    def test_non_moa_turn_emits_nothing(self, monkeypatch):
        mod = self._fresh_plugin()
        gens = []
        state = self._state(mod, monkeypatch, gens)

        for value in (None, [], "not-a-list", [None, "junk"]):
            mod._emit_moa_reference_generations(state, client=object(), references=value)

        assert gens == []

class TestAtexitFinalization(TestTurnTraceIsolation):
    """Short-lived processes (kanban workers, `hermes chat -q`, cron) can exit
    with tool calls still queued — the root span never ends and the backend
    shows an anonymous trace (no name/session/metadata). _finalize_all_traces
    (registered atexit after client construction) must end every open root."""

    def test_finalize_all_ends_open_roots_and_clears_state(self, monkeypatch):
        mod = self._fresh_plugin()
        started: list = []
        ended: list = []
        client = self._fake_client(started)
        monkeypatch.setattr(mod, "_get_langfuse", lambda: client)
        monkeypatch.setattr(
            mod, "_end_observation", lambda obs, **k: ended.append(obs)
        )
        mod._TRACE_STATE.clear()

        # Three worker-style turns that never finalize (tool calls pending).
        for n in range(3):
            self._run_turn(mod, session=f"worker-{n}", turn_n=0, finalize=False)
        assert len(mod._TRACE_STATE) == 3

        root_ends: list = []
        for state in mod._TRACE_STATE.values():
            real_end = state.root_span.end
            state.root_span.end = lambda *a, _r=real_end, **k: root_ends.append(1)

        mod._finalize_all_traces()

        assert len(root_ends) == 3, "every open root span must be ended"
        assert mod._TRACE_STATE == {}, "state must be drained"
        # Idempotent: a second call (SDK/atexit re-entry) is a no-op.
        mod._finalize_all_traces()
        assert len(root_ends) == 3

    def test_atexit_hook_is_registered_on_client_init(self, monkeypatch):
        mod = self._fresh_plugin()
        registered: list = []
        import atexit as _atexit

        monkeypatch.setattr(mod, "Langfuse", lambda **kw: object())
        monkeypatch.setattr(
            _atexit, "register", lambda fn, *a, **k: registered.append(fn)
        )
        monkeypatch.setenv("HERMES_LANGFUSE_PUBLIC_KEY", "pk-lf-...cdef")
        monkeypatch.setenv("HERMES_LANGFUSE_SECRET_KEY", "sk-lf-...cdef")
        mod._LANGFUSE_CLIENT = None

        assert mod._get_langfuse() is not None
        assert mod._finalize_all_traces in registered

    def test_finalize_flushes_every_profile_without_an_ambient_scope(self, monkeypatch, tmp_path):
        """Multiplex gateway: every turn ran inside a profile scope (home override + secret scope),
        so only the per-home slots hold clients and the launch slot stays empty. atexit has no
        scope, and a credential read there raises UnscopedSecretError. The finalizer must not read
        credentials at all — it ends the open roots and flushes each settled client, so neither
        profile loses its pending traces."""
        from agent import secret_scope
        from hermes_constants import reset_hermes_home_override, set_hermes_home_override

        mod = self._fresh_plugin()
        monkeypatch.setattr(secret_scope, "_MULTIPLEX_ACTIVE", True)
        monkeypatch.setattr(mod, "_end_observation", lambda obs, **k: None)
        mod._LANGFUSE_CLIENT = None
        mod._TRACE_STATE.clear()
        mod._LANGFUSE_CLIENT_BY_HOME.clear()

        flushed: list = []
        fake_client = self._fake_client

        def _sdk(**kw):
            client = fake_client([])
            client.flush = lambda pk=kw["public_key"]: flushed.append(pk)
            return client

        monkeypatch.setattr(mod, "Langfuse", _sdk)

        for profile in ("alpha", "beta"):
            home = tmp_path / profile
            home.mkdir()
            home_token = set_hermes_home_override(home)
            scope_token = secret_scope.set_secret_scope({
                "HERMES_LANGFUSE_PUBLIC_KEY": f"pk-lf-{profile}-0123456789",
                "HERMES_LANGFUSE_SECRET_KEY": f"sk-lf-{profile}-0123456789",
            })
            try:
                self._run_turn(mod, session=f"{profile}-turn", turn_n=0, finalize=False)
            finally:
                secret_scope.reset_secret_scope(scope_token)
                reset_hermes_home_override(home_token)

        assert len(mod._TRACE_STATE) == 2 and len(mod._LANGFUSE_CLIENT_BY_HOME) == 2
        assert mod._LANGFUSE_CLIENT is None and secret_scope.current_secret_scope() is None

        mod._finalize_all_traces()  # no scope: must not raise, must not build a client

        assert sorted(flushed) == ["pk-lf-...6789", "pk-lf-...6789"]
        assert mod._TRACE_STATE == {} and mod._LANGFUSE_CLIENT is None


class TestSystemPromptInGenerationInput:
    """The generation input must carry the system prompt even for providers
    that move it out of ``messages``: Anthropic Messages (``system`` kwarg)
    and the Responses/Codex API (``instructions``).  Hermes forwards it to
    hooks as ``system_prompt``; the plugin prepends a ``role: system`` entry.

    Regression for the trace gap discussed in PR #32175 (Anthropic) and its
    Codex sibling: without this, hosted traces show conversations without the
    agent's instructions, skills, and memory."""

    def _make_mod(self):
        sys.modules.pop("langfuse_plugin", None)
        return importlib.import_module("langfuse_plugin")

    def _capture_generation(self, mod, monkeypatch):
        """Route on_pre_llm_request into a seeded TraceState and record the
        generation observation kwargs."""
        captured = {}
        monkeypatch.setattr(mod, "_get_langfuse", lambda: object())
        state = mod.TraceState(trace_id="t", root_span=None)
        task_key = mod._trace_key("task-1", "sess-1")
        monkeypatch.setitem(mod._TRACE_STATE, task_key, state)

        def fake_child(state_, **kw):
            captured["input"] = kw.get("input_value")
            captured["metadata"] = kw.get("metadata")
            return object()

        monkeypatch.setattr(mod, "_start_child_observation", fake_child)
        return captured

    def _fire(self, mod, *, request_messages, system_prompt=None):
        kwargs = dict(
            task_id="task-1",
            session_id="sess-1",
            model="m",
            provider="p",
            api_mode="codex_responses",
            api_call_count=1,
            request_messages=request_messages,
        )
        if system_prompt is not None:
            kwargs["system_prompt"] = system_prompt
        mod.on_pre_llm_request(**kwargs)


    def test_anthropic_block_list_flattened(self, monkeypatch):
        """Anthropic OAuth mode sends ``system`` as content blocks (with
        cache_control); the trace should carry the readable text."""
        mod = self._make_mod()
        captured = self._capture_generation(mod, monkeypatch)
        blocks = [
            {"type": "text", "text": "part one", "cache_control": {"type": "ephemeral"}},
            {"type": "text", "text": "part two"},
        ]
        self._fire(
            mod,
            request_messages=[{"role": "user", "content": "hi"}],
            system_prompt=blocks,
        )
        first = captured["input"][0]
        assert first["role"] == "system"
        assert "part one" in first["content"]
        assert "part two" in first["content"]


    def test_base_url_credentials_stripped_from_generation_metadata(self, monkeypatch):
        mod = self._make_mod()
        captured = self._capture_generation(mod, monkeypatch)
        mod.on_pre_llm_request(task_id="task-1", session_id="sess-1", api_call_count=1, request_messages=[],
                               base_url="https://user:s3cr3tpass@proxy.example/v1?api_key=abcdef123456&region=us")
        assert captured["metadata"]["base_url"] == "https://***:***@proxy.example/v1?api_key=***&region=us"

    def test_absent_system_prompt_keeps_previous_shape(self, monkeypatch):
        mod = self._make_mod()
        captured = self._capture_generation(mod, monkeypatch)
        self._fire(mod, request_messages=[{"role": "user", "content": "hi"}])
        assert captured["input"][0]["role"] == "user"
        assert "system_prompt_chars" not in (captured["metadata"] or {})

    def test_system_survives_serialization_window(self, monkeypatch):
        """_serialize_messages keeps only the last 12 messages; the system
        prompt must be prepended after windowing so long conversations
        never drop it."""
        mod = self._make_mod()
        captured = self._capture_generation(mod, monkeypatch)
        many = [
            {"role": "user" if i % 2 == 0 else "assistant", "content": f"m{i}"}
            for i in range(30)
        ]
        self._fire(mod, request_messages=many, system_prompt="SYS")
        assert captured["input"][0]["role"] == "system"
        assert captured["input"][0]["content"] == "SYS"


class TestSystemPromptCrossesHookBoundary:
    """End-to-end across the hook seam with real transport-built kwargs —
    the regression coverage PR #32175's review asked for: verify the
    provider-specific request shape (Anthropic ``system`` kwarg, Codex
    ``instructions``) actually reaches the Langfuse generation input, with
    no Hermes internals mocked (only the Langfuse client is faked)."""

    def _make_mod(self):
        sys.modules.pop("langfuse_plugin", None)
        return importlib.import_module("langfuse_plugin")

    def _capture_generation(self, mod, monkeypatch):
        captured = {}
        monkeypatch.setattr(mod, "_get_langfuse", lambda: object())
        state = mod.TraceState(trace_id="t", root_span=None)
        task_key = mod._trace_key("task-1", "sess-1")
        monkeypatch.setitem(mod._TRACE_STATE, task_key, state)

        def fake_child(state_, **kw):
            captured["input"] = kw.get("input_value")
            return object()

        monkeypatch.setattr(mod, "_start_child_observation", fake_child)
        return captured

    def _derive_and_fire(self, mod, api_kwargs, api_messages):
        """Mirror agent/conversation_loop.py's pre_api_request emission:
        derive request_messages exactly the way the loop does, derive
        system_prompt via the loop's helper, and invoke the plugin hook."""
        from agent.conversation_loop import _system_prompt_for_hooks

        request_messages = api_kwargs.get("messages")
        if not isinstance(request_messages, list):
            request_messages = api_kwargs.get("input")
        if not isinstance(request_messages, list):
            request_messages = api_messages
        mod.on_pre_llm_request(
            task_id="task-1",
            session_id="sess-1",
            model="m",
            provider="p",
            api_mode="x",
            api_call_count=1,
            request_messages=list(request_messages),
            system_prompt=_system_prompt_for_hooks(api_kwargs, request_messages),
        )

    def test_codex_instructions_reach_generation_input(self, monkeypatch):
        from agent.transports.codex import ResponsesApiTransport

        api_messages = [
            {"role": "system", "content": "SYS-CODEX"},
            {"role": "user", "content": "hi"},
        ]
        api_kwargs = ResponsesApiTransport().build_kwargs("gpt-x", api_messages, None)
        # Premise: the Responses API moves the system prompt out of the input.
        assert api_kwargs["instructions"] == "SYS-CODEX"
        assert all(i.get("role") != "system" for i in api_kwargs["input"] if isinstance(i, dict))

        mod = self._make_mod()
        captured = self._capture_generation(mod, monkeypatch)
        self._derive_and_fire(mod, api_kwargs, api_messages)
        assert captured["input"][0]["role"] == "system"
        assert captured["input"][0]["content"] == "SYS-CODEX"

    def test_anthropic_system_kwarg_reaches_generation_input(self, monkeypatch):
        from agent.transports.anthropic import AnthropicTransport

        api_messages = [
            {"role": "system", "content": "SYS-ANTHROPIC"},
            {"role": "user", "content": "hi"},
        ]
        api_kwargs = AnthropicTransport().build_kwargs(
            "claude-x", api_messages, None, max_tokens=64
        )
        # Premise: the Messages API moves the system prompt to a kwarg.
        assert "system" in api_kwargs
        assert all(m.get("role") != "system" for m in api_kwargs["messages"])

        mod = self._make_mod()
        captured = self._capture_generation(mod, monkeypatch)
        self._derive_and_fire(mod, api_kwargs, api_messages)
        assert captured["input"][0]["role"] == "system"
        assert "SYS-ANTHROPIC" in captured["input"][0]["content"]

    def test_bedrock_system_kwarg_reaches_generation_input(self, monkeypatch):
        from agent.transports.bedrock import BedrockTransport

        api_messages = [
            {"role": "system", "content": "SYS-BEDROCK"},
            {"role": "user", "content": "hi"},
        ]
        api_kwargs = BedrockTransport().build_kwargs(
            "anthropic.claude-x", api_messages, None, max_tokens=64
        )
        # Premise: Bedrock Converse moves system into a separate 'system' kwarg,
        # shaped as [{"text": ...}] blocks — no "type" key, unlike Anthropic.
        # (The transport may append extra blocks, e.g. cachePoint markers.)
        assert {"text": "SYS-BEDROCK"} in api_kwargs["system"]
        assert all(m.get("role") != "system" for m in api_kwargs["messages"])

        mod = self._make_mod()
        captured = self._capture_generation(mod, monkeypatch)
        self._derive_and_fire(mod, api_kwargs, api_messages)
        assert captured["input"][0]["role"] == "system"
        assert "SYS-BEDROCK" in captured["input"][0]["content"]

    def test_chat_completions_shape_needs_no_fallback(self, monkeypatch):
        """When system stays in messages[0] (chat_completions), the helper
        returns it but the plugin must not duplicate the entry."""
        from agent.conversation_loop import _system_prompt_for_hooks

        api_kwargs = {
            "messages": [
                {"role": "system", "content": "SYS-CHAT"},
                {"role": "user", "content": "hi"},
            ]
        }
        sp = _system_prompt_for_hooks(api_kwargs, api_kwargs["messages"])
        assert sp == "SYS-CHAT"

        mod = self._make_mod()
        captured = self._capture_generation(mod, monkeypatch)
        self._derive_and_fire(mod, api_kwargs, api_kwargs["messages"])
        roles = [m["role"] for m in captured["input"]]
        assert roles.count("system") == 1
class TestFinishTraceUsesSetTraceIo:
    """Regression: the pinned SDK v4 has set_trace_io, not v3's update_trace.

    Calling the missing method once skipped root_span.end() (blank Input/Output
    columns, no CHAIN root); after that was guarded it still failed open on every
    turn, so traces shipped without trace-level input/output (hermes-agent#94710).
    """

    def test_finish_ends_root_and_calls_set_trace_io(self, monkeypatch):
        sys.modules.pop("langfuse_plugin", None)
        mod = importlib.import_module("langfuse_plugin")

        roots: list = []

        class _Span:
            def __init__(self):
                self.ended = False
                self.updates = []
                self.trace_updates = []

            def update(self, **kw):
                self.updates.append(kw)

            def end(self, **kw):
                self.ended = True

            def set_trace_io(self, **kw):
                self.trace_updates.append(kw)

            def start_observation(self, **kw):
                return _Span()

            # Deliberately NO update_trace — mirrors the pinned SDK v4 LangfuseChain.

        class _RootCM:
            def __init__(self):
                self.span = _Span()
                roots.append(self.span)

            def __enter__(self):
                return self.span

            def __exit__(self, *exc):
                return False

        class _Client:
            def create_trace_id(self, seed=None):
                return f"trace::{seed}"

            def start_as_current_observation(self, **kw):
                return _RootCM()

            def start_observation(self, **kw):
                return _RootCM().__enter__()

            def flush(self):
                pass

        monkeypatch.setattr(mod, "_get_langfuse", lambda: _Client())
        monkeypatch.setattr(mod, "_end_observation", lambda *a, **k: None)
        mod._TRACE_STATE.clear()

        mod.on_pre_llm_request(
            task_id="t1",
            session_id="s1",
            model="m",
            provider="p",
            api_mode="chat",
            api_call_count=1,
            request_messages=[{"role": "user", "content": "hi"}],
            turn_id="turn-1",
        )
        mod.on_post_llm_call(
            task_id="t1",
            session_id="s1",
            model="m",
            provider="p",
            api_mode="chat",
            api_call_count=1,
            assistant_content_chars=12,
            assistant_tool_call_count=0,
            assistant_response="hello world!",
            turn_id="turn-1",
        )

        assert len(roots) == 1
        root = roots[0]
        assert root.ended is True
        assert any("input" in u for u in root.trace_updates)
        assert any("output" in u for u in root.trace_updates)
        assert any("output" in u for u in root.updates)
        assert mod._TRACE_STATE == {}

    def test_finish_still_ends_when_set_trace_io_raises(self, monkeypatch):
        sys.modules.pop("langfuse_plugin", None)
        mod = importlib.import_module("langfuse_plugin")

        roots: list = []

        class _Span:
            def __init__(self):
                self.ended = False

            def update(self, **kw):
                pass

            def end(self, **kw):
                self.ended = True

            def set_trace_io(self, **kw):
                raise RuntimeError("simulated set_trace_io failure")

            def start_observation(self, **kw):
                return _Span()

        class _RootCM:
            def __init__(self):
                self.span = _Span()
                roots.append(self.span)

            def __enter__(self):
                return self.span

            def __exit__(self, *exc):
                return False

        class _Client:
            def create_trace_id(self, seed=None):
                return f"trace::{seed}"

            def start_as_current_observation(self, **kw):
                return _RootCM()

            def start_observation(self, **kw):
                return _RootCM().__enter__()

            def flush(self):
                pass

        monkeypatch.setattr(mod, "_get_langfuse", lambda: _Client())
        monkeypatch.setattr(mod, "_end_observation", lambda *a, **k: None)
        mod._TRACE_STATE.clear()

        mod.on_pre_llm_request(
            task_id="t1",
            session_id="s1",
            model="m",
            provider="p",
            api_mode="chat",
            api_call_count=1,
            request_messages=[{"role": "user", "content": "hi"}],
            turn_id="turn-1",
        )
        mod.on_post_llm_call(
            task_id="t1",
            session_id="s1",
            model="m",
            provider="p",
            api_mode="chat",
            api_call_count=1,
            assistant_content_chars=5,
            assistant_tool_call_count=0,
            assistant_response="done",
            turn_id="turn-1",
        )

        assert roots[0].ended is True
        assert mod._TRACE_STATE == {}

class TestCanonicalCostExport:
    """Both supported response paths must export the same complete cost."""

    @staticmethod
    def _response(input_tokens, output_tokens, cache_read=0, cache_write=0):
        cache_details = SimpleNamespace(
            cached_tokens=cache_read,
            cache_write_tokens=cache_write,
        )
        usage = SimpleNamespace(
            # Anthropic response shape.
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cache_read_input_tokens=cache_read,
            cache_creation_input_tokens=cache_write,
            # OpenAI chat response shape used by the included-route case.
            prompt_tokens=input_tokens + cache_read + cache_write,
            completion_tokens=output_tokens,
            prompt_tokens_details=cache_details,
        )
        return SimpleNamespace(usage=usage)

    @staticmethod
    def _summary(input_tokens, output_tokens, cache_read=0, cache_write=0, request_count=1):
        return {
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "cache_read_tokens": cache_read,
            "cache_write_tokens": cache_write,
            "reasoning_tokens": 0,
            "request_count": request_count,
        }

    @staticmethod
    def _capture_summary_path(mod, monkeypatch, usage, *, provider, model, api_mode):
        monkeypatch.setattr(mod, "_get_langfuse", lambda: object())
        observation = object()
        state = mod.TraceState(trace_id="trace-cost", root_span=None)
        state.generations[mod._request_key(1)] = observation
        task_key = mod._trace_key("task-cost", "session-cost")
        monkeypatch.setitem(mod._TRACE_STATE, task_key, state)
        captured = {}

        def fake_end_observation(
            obs,
            *,
            output=None,
            metadata=None,
            usage_details=None,
            cost_details=None,
            **_,
        ):
            captured["usage_details"] = usage_details
            captured["cost_details"] = cost_details

        monkeypatch.setattr(mod, "_end_observation", fake_end_observation)
        mod.on_post_llm_call(
            task_id="task-cost",
            session_id="session-cost",
            api_call_count=1,
            model=model,
            provider=provider,
            api_mode=api_mode,
            response={"model": model},
            usage=usage,
        )
        return captured["usage_details"], captured["cost_details"]

    def _run_both_paths(
        self,
        mod,
        monkeypatch,
        usage,
        *,
        provider="anthropic",
        model="priced-model",
        api_mode="anthropic_messages",
    ):
        response_result = mod._usage_and_cost(
            self._response(
                usage["input_tokens"],
                usage["output_tokens"],
                usage.get("cache_read_tokens", 0),
                usage.get("cache_write_tokens", 0),
            ),
            provider=provider,
            api_mode=api_mode,
            model=model,
            base_url="",
        )
        summary_result = self._capture_summary_path(
            mod,
            monkeypatch,
            usage,
            provider=provider,
            model=model,
            api_mode=api_mode,
        )
        assert response_result[0] == summary_result[0]
        return response_result[1], summary_result[1]

    @pytest.mark.parametrize(
        ("cache_read", "cache_write", "expected_total"),
        [
            (0, 0, 0.00002),
            (2, 3, 0.0000255),
        ],
        ids=("no-cache", "cached"),
    )
    def test_known_costs_include_canonical_total_on_both_paths(
        self,
        monkeypatch,
        cache_read,
        cache_write,
        expected_total,
    ):
        sys.modules.pop("langfuse_plugin", None)
        mod = importlib.import_module("langfuse_plugin")
        import agent.usage_pricing as pricing

        entry = pricing.PricingEntry(
            input_cost_per_million=Decimal(1),
            output_cost_per_million=Decimal(2),
            cache_read_cost_per_million=Decimal("0.5"),
            cache_write_cost_per_million=Decimal("1.5"),
            source="custom_contract",
        )
        monkeypatch.setattr(pricing, "get_pricing_entry", lambda *_, **__: entry)
        usage = self._summary(10, 5, cache_read, cache_write)

        response_cost, summary_cost = self._run_both_paths(mod, monkeypatch, usage)
        expected = {
            "total": expected_total,
            "input": 0.00001,
            "output": 0.00001,
        }
        if cache_read:
            expected["cache_read_input_tokens"] = 0.000001
        if cache_write:
            expected["cache_creation_input_tokens"] = 0.0000045
        assert response_cost == pytest.approx(expected)
        assert summary_cost == pytest.approx(expected)

    def test_total_uses_request_cost_instead_of_component_sum(self, monkeypatch):
        sys.modules.pop("langfuse_plugin", None)
        mod = importlib.import_module("langfuse_plugin")
        import agent.usage_pricing as pricing

        entry = pricing.PricingEntry(
            input_cost_per_million=Decimal(1),
            output_cost_per_million=Decimal(2),
            cache_read_cost_per_million=Decimal("0.5"),
            cache_write_cost_per_million=Decimal("1.5"),
            request_cost=Decimal("0.01"),
            source="provider_models_api",
        )
        monkeypatch.setattr(pricing, "get_pricing_entry", lambda *_, **__: entry)
        usage = self._summary(10, 5, cache_read=2, cache_write=3)

        response_cost, summary_cost = self._run_both_paths(mod, monkeypatch, usage)
        for cost_details in (response_cost, summary_cost):
            component_sum = sum(
                value for key, value in cost_details.items() if key != "total"
            )
            assert cost_details["total"] == pytest.approx(0.0100255)
            assert component_sum == pytest.approx(0.0000255)

    def test_request_only_price_still_exports_total(self, monkeypatch):
        sys.modules.pop("langfuse_plugin", None)
        mod = importlib.import_module("langfuse_plugin")
        import agent.usage_pricing as pricing

        entry = pricing.PricingEntry(
            request_cost=Decimal("0.01"),
            source="provider_models_api",
        )
        monkeypatch.setattr(pricing, "get_pricing_entry", lambda *_, **__: entry)
        usage = self._summary(0, 0)

        response_cost, summary_cost = self._run_both_paths(mod, monkeypatch, usage)
        assert response_cost == {"total": 0.01}
        assert summary_cost == {"total": 0.01}

    def test_partial_cache_pricing_exports_no_costs(self, monkeypatch):
        sys.modules.pop("langfuse_plugin", None)
        mod = importlib.import_module("langfuse_plugin")
        import agent.usage_pricing as pricing

        entry = pricing.PricingEntry(
            input_cost_per_million=Decimal(1),
            output_cost_per_million=Decimal(2),
            cache_read_cost_per_million=None,
            source="provider_models_api",
        )
        monkeypatch.setattr(pricing, "get_pricing_entry", lambda *_, **__: entry)
        usage = self._summary(10, 5, cache_read=2)

        response_cost, summary_cost = self._run_both_paths(mod, monkeypatch, usage)
        assert response_cost == {}
        assert summary_cost == {}

    def test_unknown_pricing_exports_no_costs(self, monkeypatch):
        sys.modules.pop("langfuse_plugin", None)
        mod = importlib.import_module("langfuse_plugin")
        import agent.usage_pricing as pricing

        monkeypatch.setattr(pricing, "get_pricing_entry", lambda *_, **__: None)
        usage = self._summary(10, 5)

        response_cost, summary_cost = self._run_both_paths(mod, monkeypatch, usage)
        assert response_cost == {}
        assert summary_cost == {}

    def test_included_route_does_not_pin_total(self, monkeypatch):
        sys.modules.pop("langfuse_plugin", None)
        mod = importlib.import_module("langfuse_plugin")
        usage = self._summary(10, 5, cache_read=2)

        response_cost, summary_cost = self._run_both_paths(
            mod,
            monkeypatch,
            usage,
            provider="openai-codex",
            model="gpt-5.3-codex",
            api_mode="chat_completions",
        )
        assert response_cost == summary_cost
        assert "total" not in response_cost
        # Subscription-included routes must send NO cost keys at all —
        # explicit zeros are treated as authoritative by Langfuse and block
        # its own model-based estimation (#43129).
        assert response_cost == {}


class TestChildObservationsInheritTraceAttributes:
    def test_children_are_created_inside_the_roots_propagate_attributes(self, monkeypatch):
        """hermes-agent#81730: propagate_attributes() only stamps observations created inside its
        scope. Children come from later hooks, after the root's ``with`` block closed, so they used
        to carry no session_id/tags. Every child must be opened under the root's attributes."""
        import contextlib

        sys.modules.pop("langfuse_plugin", None)
        mod = importlib.import_module("langfuse_plugin")
        active: list = []
        children: list = []
        opened: list = []

        @contextlib.contextmanager
        def _propagate(**kw):
            opened.append(dict(kw))
            active.append(kw)
            try:
                yield
            finally:
                active.pop()

        class _Span:
            def update(self, **kw): pass
            def update_trace(self, **kw): pass
            def end(self, **kw): pass
            def start_observation(self, **kw):
                children.append((kw["name"], dict(active[-1]) if active else None))
                return _Span()

        class _Client:
            def create_trace_id(self, seed=None): return f"trace::{seed}"
            def start_observation(self, **kw): return _Span()
            def flush(self): pass

        monkeypatch.setattr(mod, "propagate_attributes", _propagate)
        monkeypatch.setattr(mod, "_get_langfuse", lambda: _Client())
        common = dict(task_id="sess-p", session_id="sess-p", model="m", provider="p", api_mode="chat",
                      api_call_count=1, turn_id="sess-p:turn1", api_request_id="sess-p:turn1:api:1")
        mod.on_pre_llm_request(request_messages=[{"role": "user", "content": "hi"}], **common)
        mod.on_pre_tool_call(tool_name="terminal", args={"command": "ls"}, tool_call_id="c1",
                             task_id="sess-p", session_id="sess-p", turn_id="sess-p:turn1")

        assert [name for name, _ in children] == ["LLM call 1", "Tool: terminal"]
        assert opened[0]["session_id"] == "sess-p" and opened[0]["tags"][:2] == ["hermes", "langfuse"]
        for _, attrs in children:
            assert attrs == opened[0]  # exactly the root's session / trace name / tags
