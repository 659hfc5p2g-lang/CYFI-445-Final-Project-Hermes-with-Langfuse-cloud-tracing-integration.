#System Prompt Template
[Paste your custom instructions here]